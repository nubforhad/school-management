<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Models\Setting;

class AdmissionController extends Controller
{
    public function admission(){

        $settings = Setting::pluck('value', 'key');
        return view('frontend.admission-form', compact('settings'));
    }
}
