

<?php $__env->startSection('title', 'Expense'); ?>

<?php $__env->startSection('content'); ?>

<div class="p-4 sm:p-6">

    
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
        <div>
            <h1 class="text-xl sm:text-2xl font-bold text-slate-800">
                Expenses
            </h1>
            <p class="text-sm text-slate-500 mt-1">
                Manage branch expenses and payments.
            </p>
        </div>

        <a href="<?php echo e(route('admin.expenses.create')); ?>"
        class="inline-flex items-center justify-center gap-2 px-4 py-2.5
                bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium
                rounded-lg transition">
            <i class="bi bi-plus-lg"></i>
            Add Expense
        </a>
    </div>

    
    <?php if(session('success')): ?>
        <div class="mb-5 flex items-center gap-3 rounded-lg border border-green-200
                    bg-green-50 px-4 py-3 text-sm text-green-700">
            <i class="bi bi-check-circle-fill"></i>
            <span><?php echo e(session('success')); ?></span>
        </div>
    <?php endif; ?>

    
    <div class="bg-white border border-slate-200 rounded-xl p-4 mb-5">

        <form method="GET" action="<?php echo e(route('admin.expenses.index')); ?>">

            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">

                
                <div class="lg:col-span-2">
                    <label class="block text-xs font-medium text-slate-600 mb-1.5">
                        Search
                    </label>

                    <div class="relative">
                        <i class="bi bi-search absolute left-3 top-1/2
                                -translate-y-1/2 text-slate-400"></i>

                        <input
                            type="text"
                            name="search"
                            value="<?php echo e(request('search')); ?>"
                            placeholder="Category, reference..."
                            class="w-full rounded-lg border border-slate-300
                                pl-10 pr-4 py-2.5 text-sm
                                focus:border-blue-500 focus:ring-blue-500">
                    </div>
                </div>

                
                <div>
                    <label class="block text-xs font-medium text-slate-600 mb-1.5">
                        Category
                    </label>

                    <select name="category_id"
                            class="w-full rounded-lg border border-slate-300
                                px-3 py-2.5 text-sm
                                focus:border-blue-500 focus:ring-blue-500">

                        <option value="">All Categories</option>

                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>"
                                <?php echo e(request('category_id') == $category->id ? 'selected' : ''); ?>>
                                <?php echo e($category->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>
                </div>

                
                <div>
                    <label class="block text-xs font-medium text-slate-600 mb-1.5">
                        Payment Method
                    </label>

                    <select name="payment_method"
                            class="w-full rounded-lg border border-slate-300
                                px-3 py-2.5 text-sm
                                focus:border-blue-500 focus:ring-blue-500">

                        <option value="">All Methods</option>
                        <option value="cash" <?php echo e(request('payment_method') == 'cash' ? 'selected' : ''); ?>>
                            Cash
                        </option>
                        <option value="bank" <?php echo e(request('payment_method') == 'bank' ? 'selected' : ''); ?>>
                            Bank
                        </option>
                        <option value="mobile_banking" <?php echo e(request('payment_method') == 'mobile_banking' ? 'selected' : ''); ?>>
                            Mobile Banking
                        </option>
                        <option value="cheque" <?php echo e(request('payment_method') == 'cheque' ? 'selected' : ''); ?>>
                            Cheque
                        </option>
                        <option value="other" <?php echo e(request('payment_method') == 'other' ? 'selected' : ''); ?>>
                            Other
                        </option>

                    </select>
                </div>

                
                <div>
                    <label class="block text-xs font-medium text-slate-600 mb-1.5">
                        Status
                    </label>

                    <select name="status"
                            class="w-full rounded-lg border border-slate-300
                                px-3 py-2.5 text-sm
                                focus:border-blue-500 focus:ring-blue-500">

                        <option value="">All Status</option>
                        <option value="1" <?php echo e(request('status') === '1' ? 'selected' : ''); ?>>
                            Active
                        </option>
                        <option value="0" <?php echo e(request('status') === '0' ? 'selected' : ''); ?>>
                            Inactive
                        </option>

                    </select>
                </div>

                
                <div class="flex items-end gap-2">

                    <button type="submit"
                            class="flex-1 inline-flex items-center justify-center gap-2
                                px-4 py-2.5 bg-slate-800 hover:bg-slate-900
                                text-white text-sm font-medium rounded-lg transition">
                        <i class="bi bi-funnel"></i>
                        Filter
                    </button>

                    <?php if(request()->hasAny([
                        'search',
                        'category_id',
                        'payment_method',
                        'status',
                        'date_from',
                        'date_to'
                    ])): ?>
                        <a href="<?php echo e(route('admin.expenses.index')); ?>"
                        class="inline-flex items-center justify-center w-11 h-10
                                rounded-lg bg-slate-100 hover:bg-slate-200
                                text-slate-600"
                        title="Clear Filters">
                            <i class="bi bi-x-lg"></i>
                        </a>
                    <?php endif; ?>

                </div>

            </div>

            
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-3 max-w-md">

                <div>
                    <label class="block text-xs font-medium text-slate-600 mb-1.5">
                        Date From
                    </label>

                    <input type="date"
                        name="date_from"
                        value="<?php echo e(request('date_from')); ?>"
                        class="w-full rounded-lg border border-slate-300
                                px-3 py-2.5 text-sm
                                focus:border-blue-500 focus:ring-blue-500">
                </div>

                <div>
                    <label class="block text-xs font-medium text-slate-600 mb-1.5">
                        Date To
                    </label>

                    <input type="date"
                        name="date_to"
                        value="<?php echo e(request('date_to')); ?>"
                        class="w-full rounded-lg border border-slate-300
                                px-3 py-2.5 text-sm
                                focus:border-blue-500 focus:ring-blue-500">
                </div>

            </div>

        </form>
    </div>

    
    <div class="bg-white border border-slate-200 rounded-xl overflow-hidden">

        <div class="overflow-x-auto">

            <table class="w-full text-sm text-left">

                <thead class="bg-slate-50 border-b border-slate-200">
                    <tr>
                        <th class="px-5 py-3 font-semibold text-slate-600">#</th>
                        <th class="px-5 py-3 font-semibold text-slate-600">Date</th>
                        <th class="px-5 py-3 font-semibold text-slate-600">Category</th>
                        <th class="px-5 py-3 font-semibold text-slate-600">Amount</th>
                        <th class="px-5 py-3 font-semibold text-slate-600">Payment</th>
                        <th class="px-5 py-3 font-semibold text-slate-600">Status</th>
                        <th class="px-5 py-3 font-semibold text-slate-600 text-right">
                            Actions
                        </th>
                    </tr>
                </thead>

                <tbody class="divide-y divide-slate-100">

                    <?php $__empty_1 = true; $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                        <tr class="hover:bg-slate-50 transition">

                            <td class="px-5 py-4 text-slate-500">
                                <?php echo e($expenses->firstItem() + $loop->index); ?>

                            </td>

                            <td class="px-5 py-4 whitespace-nowrap">
                                <span class="font-medium text-slate-700">
                                    <?php echo e($expense->expense_date?->format('d M Y')); ?>

                                </span>
                            </td>

                            <td class="px-5 py-4">
                                <div class="font-medium text-slate-800">
                                    <?php echo e($expense->category?->name ?? '—'); ?>

                                </div>

                                <?php if($expense->reference_no): ?>
                                    <div class="text-xs text-slate-400 mt-1">
                                        Ref: <?php echo e($expense->reference_no); ?>

                                    </div>
                                <?php endif; ?>
                            </td>

                            <td class="px-5 py-4 whitespace-nowrap">
                                <span class="font-semibold text-slate-800">
                                    ৳ <?php echo e(number_format((float) $expense->amount, 2)); ?>

                                </span>
                            </td>

                            <td class="px-5 py-4">
                                <?php
                                    $paymentMethods = [
                                        'cash' => 'Cash',
                                        'bank' => 'Bank',
                                        'mobile_banking' => 'Mobile Banking',
                                        'cheque' => 'Cheque',
                                        'other' => 'Other',
                                    ];
                                ?>

                                <span class="text-slate-600">
                                    <?php echo e($paymentMethods[$expense->payment_method] ?? ucfirst($expense->payment_method)); ?>

                                </span>
                            </td>

                            <td class="px-5 py-4">
                                <?php if($expense->status): ?>
                                    <span class="inline-flex items-center gap-1.5
                                                px-2.5 py-1 rounded-full
                                                text-xs font-medium bg-green-50 text-green-700">
                                        <span class="w-1.5 h-1.5 rounded-full bg-green-500"></span>
                                        Active
                                    </span>
                                <?php else: ?>
                                    <span class="inline-flex items-center gap-1.5
                                                px-2.5 py-1 rounded-full
                                                text-xs font-medium bg-red-50 text-red-700">
                                        <span class="w-1.5 h-1.5 rounded-full bg-red-500"></span>
                                        Inactive
                                    </span>
                                <?php endif; ?>
                            </td>

                            <td class="px-5 py-4">
                                <div class="flex items-center justify-end gap-2">

                                    <a href="<?php echo e(route('admin.expenses.show', $expense)); ?>"
                                    title="View"
                                    class="inline-flex items-center justify-center
                                            w-9 h-9 rounded-lg bg-blue-50
                                            text-blue-600 hover:bg-blue-100">
                                        <i class="bi bi-eye"></i>
                                    </a>

                                    <a href="<?php echo e(route('admin.expenses.edit', $expense)); ?>"
                                    title="Edit"
                                    class="inline-flex items-center justify-center
                                            w-9 h-9 rounded-lg bg-amber-50
                                            text-amber-600 hover:bg-amber-100">
                                        <i class="bi bi-pencil-square"></i>
                                    </a>

                                    <form action="<?php echo e(route('admin.expenses.destroy', $expense)); ?>"
                                        method="POST"
                                        class="delete-form">

                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>

                                        <button type="submit"
                                                title="Delete"
                                                class="inline-flex items-center justify-center
                                                    w-9 h-9 rounded-lg bg-red-50
                                                    text-red-600 hover:bg-red-100">
                                            <i class="bi bi-trash"></i>
                                        </button>

                                    </form>

                                </div>
                            </td>

                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <tr>
                            <td colspan="7" class="px-5 py-12 text-center">

                                <div class="flex flex-col items-center justify-center">

                                    <div class="w-12 h-12 rounded-full bg-slate-100
                                                flex items-center justify-center mb-3">
                                        <i class="bi bi-cash-stack text-xl text-slate-400"></i>
                                    </div>

                                    <h3 class="text-sm font-semibold text-slate-700">
                                        No Expenses Found
                                    </h3>

                                    <p class="text-sm text-slate-500 mt-1">
                                        No expense records match your filters.
                                    </p>

                                    <a href="<?php echo e(route('admin.expenses.create')); ?>"
                                    class="mt-4 inline-flex items-center gap-2
                                            px-4 py-2 bg-blue-600 hover:bg-blue-700
                                            text-white text-sm font-medium rounded-lg">
                                        <i class="bi bi-plus-lg"></i>
                                        Add Expense
                                    </a>

                                </div>

                            </td>
                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

        <?php if($expenses->hasPages()): ?>
            <div class="px-5 py-4 border-t border-slate-200">
                <?php echo e($expenses->links()); ?>

            </div>
        <?php endif; ?>

    </div>

</div>

<script>
    document.addEventListener('DOMContentLoaded', function () {

        document.querySelectorAll('.delete-form').forEach(function (form) {

            form.addEventListener('submit', function (event) {
                event.preventDefault();

                Swal.fire({
                    title: 'Delete Expense?',
                    text: 'This action cannot be undone.',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#dc2626',
                    cancelButtonColor: '#64748b',
                    confirmButtonText: 'Yes, Delete',
                    cancelButtonText: 'Cancel'
                }).then((result) => {

                    if (result.isConfirmed) {
                        form.submit();
                    }

                });
            });

        });

    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\school-management\resources\views/admin/expenses/index.blade.php ENDPATH**/ ?>