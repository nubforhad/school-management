

<?php $__env->startSection('title', 'Income Categories'); ?>

<?php $__env->startSection('content'); ?>

<div class="mx-auto max-w-7xl space-y-6">

    
    <div class="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">

        <div>
            <h1 class="text-2xl font-bold text-slate-800">
                Income Categories
            </h1>

            <p class="mt-1 text-sm text-slate-500">
                Manage income categories for your branch.
            </p>
        </div>

        <a href="<?php echo e(route('admin.income-categories.create')); ?>"
           class="inline-flex items-center justify-center rounded-lg bg-blue-600 px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-blue-700">

            + Add Income Category

        </a>

    </div>

    
    <?php if(session('success')): ?>
        <div class="rounded-lg border border-green-200 bg-green-50 px-4 py-3 text-sm text-green-700">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    
    <div class="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">

        <form method="GET"
              action="<?php echo e(route('admin.income-categories.index')); ?>"
              class="flex flex-col gap-3 sm:flex-row">

            <input
                type="text"
                name="search"
                value="<?php echo e(request('search')); ?>"
                placeholder="Search income category..."
                class="w-full rounded-lg border border-slate-300 px-4 py-2.5 text-sm focus:border-blue-500 focus:ring-blue-500 sm:max-w-md"
            >

            <button
                type="submit"
                class="rounded-lg bg-slate-800 px-5 py-2.5 text-sm font-semibold text-white hover:bg-slate-900">
                Search
            </button>

            <?php if(request('search')): ?>
                <a
                    href="<?php echo e(route('admin.income-categories.index')); ?>"
                    class="rounded-lg border border-slate-300 px-5 py-2.5 text-center text-sm font-semibold text-slate-700 hover:bg-slate-50">
                    Reset
                </a>
            <?php endif; ?>

        </form>

    </div>

    
    <div class="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">

        <div class="overflow-x-auto">

            <table class="min-w-full divide-y divide-slate-200">

                <thead class="bg-slate-50">

                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-semibold uppercase text-slate-500">
                            #
                        </th>

                        <th class="px-6 py-3 text-left text-xs font-semibold uppercase text-slate-500">
                            Category
                        </th>

                        <th class="px-6 py-3 text-left text-xs font-semibold uppercase text-slate-500">
                            Description
                        </th>

                        <th class="px-6 py-3 text-left text-xs font-semibold uppercase text-slate-500">
                            Status
                        </th>

                        <th class="px-6 py-3 text-right text-xs font-semibold uppercase text-slate-500">
                            Action
                        </th>
                    </tr>

                </thead>

                <tbody class="divide-y divide-slate-100">

                    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                        <tr class="hover:bg-slate-50">

                            <td class="whitespace-nowrap px-6 py-4 text-sm text-slate-500">
                                <?php echo e($categories->firstItem() + $loop->index); ?>

                            </td>

                            <td class="px-6 py-4">

                                <div class="font-semibold text-slate-800">
                                    <?php echo e($category->name); ?>

                                </div>

                            </td>

                            <td class="px-6 py-4 text-sm text-slate-600">
                                <?php echo e($category->description ?: '—'); ?>

                            </td>

                            <td class="px-6 py-4">

                                <?php if($category->status): ?>

                                    <span class="rounded-full bg-green-50 px-3 py-1 text-xs font-semibold text-green-700">
                                        Active
                                    </span>

                                <?php else: ?>

                                    <span class="rounded-full bg-red-50 px-3 py-1 text-xs font-semibold text-red-700">
                                        Inactive
                                    </span>

                                <?php endif; ?>

                            </td>

                            <td class="px-6 py-4">

                                <div class="flex justify-end gap-2">

                                    <a
                                        href="<?php echo e(route('admin.income-categories.edit', $category)); ?>"
                                        class="rounded-lg bg-blue-50 px-3 py-2 text-xs font-semibold text-blue-700 hover:bg-blue-100">
                                        Edit
                                    </a>

                                    <form
                                        action="<?php echo e(route('admin.income-categories.destroy', $category)); ?>"
                                        method="POST"
                                        onsubmit="return confirm('Are you sure you want to delete this category?');"
                                    >

                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>

                                        <button
                                            type="submit"
                                            class="rounded-lg bg-red-50 px-3 py-2 text-xs font-semibold text-red-700 hover:bg-red-100">
                                            Delete
                                        </button>

                                    </form>

                                </div>

                            </td>

                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <tr>

                            <td colspan="5"
                                class="px-6 py-12 text-center text-sm text-slate-500">

                                No income categories found.

                            </td>

                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

        <?php if($categories->hasPages()): ?>

            <div class="border-t border-slate-200 px-6 py-4">
                <?php echo e($categories->links()); ?>

            </div>

        <?php endif; ?>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\school-management\resources\views/admin/income-categories/index.blade.php ENDPATH**/ ?>