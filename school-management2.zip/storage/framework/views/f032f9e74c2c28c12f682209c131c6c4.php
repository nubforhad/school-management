


<?php $__env->startSection('content'); ?>
<div class="space-y-5 p-4 md:p-6">

    <div>
        <h1 class="text-2xl font-bold text-slate-800">Edit Role</h1>
        <p class="mt-1 text-sm text-slate-500">
            Update role information and permissions.
        </p>
    </div>

    <?php if($errors->any()): ?>
        <div class="rounded-lg border border-red-200 bg-red-50 p-3 text-red-700">
            <ul class="list-inside list-disc">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('admin.roles.update', $role)); ?>"
          method="POST" class="space-y-5">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="rounded-xl border border-slate-200 bg-white p-5">
            <label for="name" class="mb-2 block text-sm font-medium text-slate-700">
                Role Name <span class="text-red-500">*</span>
            </label>

            <input type="text" id="name" name="name"
                   value="<?php echo e(old('name', $role->name)); ?>"
                   maxlength="100" required
                   <?php if($role->name === 'Super Admin'): echo 'disabled'; endif; ?>
                   class="w-full rounded-lg border border-slate-300 px-3 py-2 focus:border-blue-500 focus:outline-none">

            <?php if($role->name === 'Super Admin'): ?>
                <p class="mt-2 text-sm text-amber-700">
                    The Super Admin role name cannot be changed here.
                </p>
            <?php endif; ?>

            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="rounded-xl border border-slate-200 bg-white">
            <div class="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 bg-slate-50 p-4">
                <div>
                    <h2 class="font-semibold text-slate-800">Permissions</h2>
                    <p class="text-sm text-slate-500">
                        Checked permissions are currently assigned to this role.
                    </p>
                </div>

                <div class="flex gap-2">
                    <button type="button"
                            onclick="document.querySelectorAll('.permission-checkbox').forEach(el => el.checked = true)"
                            class="rounded-md border border-slate-300 bg-white px-3 py-2 text-sm">
                        Select All
                    </button>

                    <button type="button"
                            onclick="document.querySelectorAll('.permission-checkbox').forEach(el => el.checked = false)"
                            class="rounded-md border border-slate-300 bg-white px-3 py-2 text-sm">
                        Clear All
                    </button>
                </div>
            </div>

            <div class="space-y-4 p-4">
                <?php $__empty_1 = true; $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module => $modulePermissions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="overflow-hidden rounded-lg border border-slate-200">
                        <div class="flex items-center justify-between bg-slate-50 px-4 py-3">
                            <h3 class="font-semibold capitalize text-slate-800">
                                <?php echo e(str_replace('-', ' ', $module)); ?>

                            </h3>

                            <button type="button"
                                    onclick="this.closest('.module-box').querySelectorAll('.permission-checkbox').forEach(el => el.checked = true)"
                                    class="text-sm text-blue-600 hover:underline">
                                Select Module
                            </button>
                        </div>

                        <div class="module-box grid grid-cols-2 gap-3 p-4 sm:grid-cols-3 lg:grid-cols-4">
                            <?php $__currentLoopData = $modulePermissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <label class="flex items-center gap-2 text-sm text-slate-700">
                                    <input type="checkbox"
                                           name="permissions[]"
                                           value="<?php echo e($permission->id); ?>"
                                           class="permission-checkbox rounded border-slate-300 text-blue-600"
                                           <?php if(in_array(
                                               $permission->id,
                                               old('permissions', $selectedPermissions)
                                           )): echo 'checked'; endif; ?>>

                                    <?php echo e(\Illuminate\Support\Str::after($permission->name, '.')); ?>

                                </label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-sm text-slate-500">
                        No permissions found.
                    </p>
                <?php endif; ?>
            </div>
        </div>

        <div class="flex flex-wrap gap-3">
            <button type="submit"
                    class="rounded-lg bg-blue-600 px-5 py-2.5 text-white hover:bg-blue-700">
                Update Role & Permissions
            </button>

            <a href="<?php echo e(route('admin.roles.index')); ?>"
               class="rounded-lg border border-slate-300 px-5 py-2.5 text-slate-700">
                Cancel
            </a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\school-management\resources\views/admin/roles/edit.blade.php ENDPATH**/ ?>