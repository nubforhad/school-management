

<?php $__env->startSection('title', 'User Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="mx-auto max-w-7xl space-y-6">

    
    <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
            <h1 class="text-2xl font-bold text-slate-800">User Management</h1>
            <p class="mt-1 text-sm text-slate-500">
                Manage system users and their assigned roles.
            </p>
        </div>

        <a href="<?php echo e(route('admin.users.create')); ?>"
           class="inline-flex items-center justify-center rounded-lg bg-blue-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-blue-700">
            + Create User
        </a>
    </div>

    
    <?php if(session('success')): ?>
        <div class="rounded-lg border border-green-200 bg-green-50 px-4 py-3 text-sm text-green-700">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    
    <?php if(session('error')): ?>
        <div class="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    
    <div class="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-slate-200 text-sm">
                <thead class="bg-slate-50">
                    <tr>
                        <th class="px-5 py-3 text-left font-semibold text-slate-600">#</th>
                        <th class="px-5 py-3 text-left font-semibold text-slate-600">User</th>
                        <th class="px-5 py-3 text-left font-semibold text-slate-600">Email</th>
                        <th class="px-5 py-3 text-left font-semibold text-slate-600">Role</th>
                        <th class="px-5 py-3 text-center font-semibold text-slate-600">Action</th>
                    </tr>
                </thead>

                <tbody class="divide-y divide-slate-100">
                    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-slate-50">
                            <td class="whitespace-nowrap px-5 py-4 text-slate-500">
                                <?php echo e($users->firstItem() + $loop->index); ?>

                            </td>

                            <td class="whitespace-nowrap px-5 py-4 font-medium text-slate-800">
                                <?php echo e($user->name); ?>

                            </td>

                            <td class="whitespace-nowrap px-5 py-4 text-slate-600">
                                <?php echo e($user->email); ?>

                            </td>

                            <td class="px-5 py-4">
                                <div class="flex flex-wrap gap-1">
                                    <?php $__empty_2 = true; $__currentLoopData = $user->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                        <span class="rounded-full bg-blue-50 px-2.5 py-1 text-xs font-medium text-blue-700">
                                            <?php echo e($role); ?>

                                        </span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                        <span class="rounded-full bg-slate-100 px-2.5 py-1 text-xs text-slate-500">
                                            No role assigned
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </td>

                            <td class="whitespace-nowrap px-5 py-4">
                                <div class="flex items-center justify-center gap-2">
                                    <a href="<?php echo e(route('admin.users.edit', $user)); ?>"
                                       class="rounded-lg border border-slate-200 px-3 py-1.5 font-medium text-blue-600 hover:bg-blue-50">
                                        Edit
                                    </a>

                                    <?php if($user->id !== auth()->id()): ?>
                                        <form action="<?php echo e(route('admin.users.destroy', $user)); ?>"
                                              method="POST"
                                              onsubmit="return confirm('Are you sure you want to delete this user?')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>

                                            <button type="submit"
                                                    class="rounded-lg border border-red-200 px-3 py-1.5 font-medium text-red-600 hover:bg-red-50">
                                                Delete
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="px-5 py-10 text-center text-slate-500">
                                No users found.
                                <a href="<?php echo e(route('admin.users.create')); ?>"
                                   class="font-semibold text-blue-600 hover:underline">
                                    Create your first user
                                </a>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if($users->hasPages()): ?>
            <div class="border-t border-slate-200 px-5 py-4">
                <?php echo e($users->links()); ?>

            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\school-management\resources\views/admin/users/index.blade.php ENDPATH**/ ?>