

<?php $__env->startSection('title', 'General Settings'); ?>

<?php $__env->startSection('content'); ?>

<div class="mx-auto max-w-7xl space-y-6">

<div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
    <div>
        <h1 class="text-2xl font-bold text-slate-800">
            General Settings
        </h1>
        <p class="mt-1 text-sm text-slate-500">
            Manage global information of your ERP.
        </p>
    </div>
</div>

<?php if(session('success')): ?>
    <div class="rounded-lg border border-green-200 bg-green-50 px-4 py-3 text-sm text-green-700">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php if($errors->any()): ?>
    <div class="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
        <div class="font-semibold">Please fix the following errors:</div>
        <ul class="mt-2 list-disc space-y-1 pl-5">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<form action="<?php echo e(route('admin.settings.general.update')); ?>" method="POST" enctype="multipart/form-data" class="space-y-6">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    
    <div class="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
        <div class="border-b border-slate-200 bg-slate-50 px-5 py-4">
            <h2 class="text-lg font-semibold text-slate-800"> Institute Information </h2>
            <p class="mt-1 text-sm text-slate-500">
                Basic information of your institute.
            </p>
        </div>
        <div class="grid grid-cols-1 gap-5 p-5 md:grid-cols-2">
            
            <div>
                <label class="mb-1 block text-sm font-medium text-slate-700">
                    Institute Name <span class="text-red-500">*</span>
                </label>
                <input type="text" name="institute_name" value="<?php echo e(old('institute_name', $settings['institute_name'] ?? '')); ?>" required
                    class="w-full rounded-lg border border-slate-300 px-3 py-2.5 text-sm outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-100" placeholder="ABC School & College">
                <?php $__errorArgs = ['institute_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <label class="mb-1 block text-sm font-medium text-slate-700">  Short Name </label>
                <input type="text" name="short_name" value="<?php echo e(old('short_name', $settings['short_name'] ?? '')); ?>" class="w-full rounded-lg border border-slate-300 px-3 py-2.5 text-sm outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-100" placeholder="ABC" >
                <?php $__errorArgs = ['short_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <label class="mb-1 block text-sm font-medium text-slate-700">  EIIN / Registration No </label>
                <input type="text" name="eiin" value="<?php echo e(old('eiin', $settings['eiin'] ?? '')); ?>" class="w-full rounded-lg border border-slate-300 px-3 py-2.5 text-sm outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
                    placeholder="123456">
                <?php $__errorArgs = ['eiin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <label class="mb-1 block text-sm font-medium text-slate-700"> Tagline </label>
                <input type="text" name="tagline" value="<?php echo e(old('tagline', $settings['tagline'] ?? '')); ?>" class="w-full rounded-lg border border-slate-300 px-3 py-2.5 text-sm outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-100" placeholder="Quality Education">
                <?php $__errorArgs = ['tagline'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    </div>

    
    <div class="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
        <div class="border-b border-slate-200 bg-slate-50 px-5 py-4">
            <h2 class="text-lg font-semibold text-slate-800">
                Contact Information
            </h2>
        </div>
        <div class="grid grid-cols-1 gap-5 p-5 md:grid-cols-2">
            
            <div class="md:col-span-2">
                <label class="mb-1 block text-sm font-medium text-slate-700">
                    Address
                </label>
                <textarea name="address" rows="3" class="w-full rounded-lg border border-slate-300 px-3 py-2.5 text-sm outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
                    placeholder="Dhaka, Bangladesh"
                ><?php echo e(old('address', $settings['address'] ?? '')); ?></textarea>
                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div>
                <label class="mb-1 block text-sm font-medium text-slate-700">
                    Phone
                </label>
                <input type="text" name="phone" value="<?php echo e(old('phone', $settings['phone'] ?? '')); ?>"
                    class="w-full rounded-lg border border-slate-300 px-3 py-2.5 text-sm outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-100" placeholder="017XXXXXXXX">
                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div>
                <label class="mb-1 block text-sm font-medium text-slate-700">
                    Email
                </label>

                <input type="email" name="email" value="<?php echo e(old('email', $settings['email'] ?? '')); ?>"
                    class="w-full rounded-lg border border-slate-300 px-3 py-2.5 text-sm outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
                    placeholder="info@example.com">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            
            <div class="md:col-span-2">
                <label class="mb-1 block text-sm font-medium text-slate-700">
                    Website
                </label>

                <input type="text" name="website"
                    value="<?php echo e(old('website', $settings['website'] ?? '')); ?>"
                    class="w-full rounded-lg border border-slate-300 px-3 py-2.5 text-sm outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
                    placeholder="www.example.com" >

                <?php $__errorArgs = ['website'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

        </div>
    </div>

    
    <div class="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">

        <div class="border-b border-slate-200 bg-slate-50 px-5 py-4">
            <h2 class="text-lg font-semibold text-slate-800">
                Logo & Favicon
            </h2>

            <p class="mt-1 text-sm text-slate-500">
                Upload institute logo and browser favicon.
            </p>
        </div>

        <div class="grid grid-cols-1 gap-6 p-5 md:grid-cols-2">

            
            <div>
                <label class="mb-1 block text-sm font-medium text-slate-700">
                    Logo
                </label>

                <input
                    type="file"
                    name="logo"
                    accept=".jpg,.jpeg,.png,.webp"
                    class="block w-full rounded-lg border border-slate-300 bg-white text-sm text-slate-600 file:mr-4 file:border-0 file:bg-slate-100 file:px-4 file:py-2.5 file:text-sm file:font-medium"
                >

                <p class="mt-1 text-xs text-slate-500">
                    JPG, JPEG, PNG or WEBP. Maximum 2MB.
                </p>

                <?php if(!empty($settings['logo'])): ?>
                    <div class="mt-4">
                        <p class="mb-2 text-xs font-medium text-slate-500">
                            Current Logo
                        </p>

                        <div class="flex h-24 w-48 items-center justify-center rounded-lg border border-slate-200 bg-slate-50 p-3">
                            <img
                                src="<?php echo e(asset('storage/' . $settings['logo'])); ?>"
                                alt="Institute Logo"
                                class="max-h-20 max-w-full object-contain"
                            >
                        </div>
                    </div>
                <?php endif; ?>

                <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div>
                <label class="mb-1 block text-sm font-medium text-slate-700">
                    Favicon
                </label>

                <input
                    type="file"
                    name="favicon"
                    accept=".ico,.png,.jpg,.jpeg,.webp"
                    class="block w-full rounded-lg border border-slate-300 bg-white text-sm text-slate-600 file:mr-4 file:border-0 file:bg-slate-100 file:px-4 file:py-2.5 file:text-sm file:font-medium"
                >

                <p class="mt-1 text-xs text-slate-500">
                    ICO, PNG, JPG, JPEG or WEBP. Maximum 1MB.
                </p>

                <?php if(!empty($settings['favicon'])): ?>
                    <div class="mt-4">
                        <p class="mb-2 text-xs font-medium text-slate-500">
                            Current Favicon
                        </p>

                        <div class="flex h-20 w-20 items-center justify-center rounded-lg border border-slate-200 bg-slate-50 p-3">
                            <img
                                src="<?php echo e(asset('storage/' . $settings['favicon'])); ?>"
                                alt="Favicon"
                                class="max-h-12 max-w-12 object-contain"
                            >
                        </div>
                    </div>
                <?php endif; ?>

                <?php $__errorArgs = ['favicon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

        </div>
    </div>

    
    <div class="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">

        <div class="border-b border-slate-200 bg-slate-50 px-5 py-4">
            <h2 class="text-lg font-semibold text-slate-800">
                Localization & Currency
            </h2>

            <p class="mt-1 text-sm text-slate-500">
                Configure currency, timezone and date format.
            </p>
        </div>

        <div class="grid grid-cols-1 gap-5 p-5 md:grid-cols-2">

            
            <div>
                <label class="mb-1 block text-sm font-medium text-slate-700">
                    Currency <span class="text-red-500">*</span>
                </label>

                <input
                    type="text"
                    name="currency"
                    value="<?php echo e(old('currency', $settings['currency'] ?? 'BDT')); ?>"
                    required
                    class="w-full rounded-lg border border-slate-300 px-3 py-2.5 text-sm outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
                    placeholder="BDT"
                >

                <?php $__errorArgs = ['currency'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div>
                <label class="mb-1 block text-sm font-medium text-slate-700">
                    Currency Symbol <span class="text-red-500">*</span>
                </label>

                <input
                    type="text"
                    name="currency_symbol"
                    value="<?php echo e(old('currency_symbol', $settings['currency_symbol'] ?? '৳')); ?>"
                    required
                    class="w-full rounded-lg border border-slate-300 px-3 py-2.5 text-sm outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
                    placeholder="৳"
                >

                <?php $__errorArgs = ['currency_symbol'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div>
                <label class="mb-1 block text-sm font-medium text-slate-700">
                    Timezone <span class="text-red-500">*</span>
                </label>

                <select
                    name="timezone"
                    required
                    class="w-full rounded-lg border border-slate-300 bg-white px-3 py-2.5 text-sm outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
                >
                    <option value="Asia/Dhaka" <?php if(old('timezone', $settings['timezone'] ?? 'Asia/Dhaka') === 'Asia/Dhaka'): echo 'selected'; endif; ?>>
                        Asia/Dhaka
                    </option>

                    <option value="Asia/Kolkata" <?php if(old('timezone', $settings['timezone'] ?? '') === 'Asia/Kolkata'): echo 'selected'; endif; ?>>
                        Asia/Kolkata
                    </option>

                    <option value="UTC" <?php if(old('timezone', $settings['timezone'] ?? '') === 'UTC'): echo 'selected'; endif; ?>>
                        UTC
                    </option>
                </select>

                <?php $__errorArgs = ['timezone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div>
                <label class="mb-1 block text-sm font-medium text-slate-700">
                    Date Format <span class="text-red-500">*</span>
                </label>

                <select
                    name="date_format"
                    required
                    class="w-full rounded-lg border border-slate-300 bg-white px-3 py-2.5 text-sm outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
                >
                    <option value="d M Y" <?php if(old('date_format', $settings['date_format'] ?? 'd M Y') === 'd M Y'): echo 'selected'; endif; ?>>
                        08 Oct 2026
                    </option>

                    <option value="d-m-Y" <?php if(old('date_format', $settings['date_format'] ?? '') === 'd-m-Y'): echo 'selected'; endif; ?>>
                        08-10-2026
                    </option>

                    <option value="d/m/Y" <?php if(old('date_format', $settings['date_format'] ?? '') === 'd/m/Y'): echo 'selected'; endif; ?>>
                        08/10/2026
                    </option>

                    <option value="Y-m-d" <?php if(old('date_format', $settings['date_format'] ?? '') === 'Y-m-d'): echo 'selected'; endif; ?>>
                        2026-10-08
                    </option>
                </select>

                <?php $__errorArgs = ['date_format'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

        </div>
    </div>

    
    <div class="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">

        <div class="border-b border-slate-200 bg-slate-50 px-5 py-4">
            <h2 class="text-lg font-semibold text-slate-800">
                Footer
            </h2>
        </div>

        <div class="p-5">

            <label class="mb-1 block text-sm font-medium text-slate-700">
                Footer Text
            </label>

            <textarea
                name="footer_text"
                rows="3"
                class="w-full rounded-lg border border-slate-300 px-3 py-2.5 text-sm outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
                placeholder="© 2026 ABC School | All Rights Reserved"
            ><?php echo e(old('footer_text', $settings['footer_text'] ?? '')); ?></textarea>

            <?php $__errorArgs = ['footer_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>
    </div>

    
    <div class="flex justify-end">

        <button
            type="submit"
            class="inline-flex items-center rounded-lg bg-blue-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-200"
        >
            Save General Settings
        </button>

    </div>

</form> 

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\school-management\resources\views/admin/settings/general.blade.php ENDPATH**/ ?>