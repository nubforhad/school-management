

<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('page-title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<div class="w-full space-y-6">

    

    <div class="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">

        <div>

            <p class="text-sm font-medium text-blue-600">
                <?php echo e(now()->format('l, d F Y')); ?>

            </p>

            <h1 class="mt-1 text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl">
                Dashboard
            </h1>

            <p class="mt-1 text-sm text-slate-500">
                Welcome back. Here's what's happening today.
            </p>

        </div>


        

        <form method="GET" action="<?php echo e(route('dashboard')); ?>" class="flex items-center gap-3">

            <select name="branch_id" onchange="this.form.submit()" class="rounded-xl border border-slate-200 bg-white
                       px-4 py-3 text-sm font-medium text-slate-700
                       shadow-sm outline-none focus:border-blue-500
                       focus:ring-2 focus:ring-blue-100">

                <option value="">
                    All Branches
                </option>

                <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <option value="<?php echo e($item->id); ?>" <?php if($branchId==$item->id): echo 'selected'; endif; ?>
                    >
                    <?php echo e($item->name); ?>

                </option>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </select>

        </form>

    </div>


    

    <?php if($branch): ?>

    <div class="flex items-center gap-3 rounded-2xl border
                    border-blue-100 bg-blue-50 px-5 py-4">

        <div class="flex h-11 w-11 items-center justify-center
                        rounded-xl bg-white text-xl shadow-sm">
            🏫
        </div>

        <div>

            <p class="text-xs font-medium uppercase tracking-wide
                          text-blue-500">
                Current Branch
            </p>

            <p class="text-sm font-bold text-slate-900">
                <?php echo e($branch->name); ?>

            </p>

        </div>

    </div>

    <?php endif; ?>


    

    <div class="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">

        
        <div class="rounded-2xl border border-slate-200 bg-white
                    p-5 shadow-sm transition hover:-translate-y-0.5
                    hover:shadow-md">

            <div class="flex items-start justify-between">

                <div>

                    <p class="text-sm font-medium text-slate-500">
                        Total Students
                    </p>

                    <h2 class="mt-2 text-3xl font-bold text-slate-900">
                        <?php echo e(number_format($totalStudents)); ?>

                    </h2>

                    <p class="mt-2 text-xs font-medium text-green-600">
                        <?php echo e(number_format($activeStudents)); ?> Active
                    </p>

                </div>

                <div class="flex h-12 w-12 items-center justify-center
                            rounded-xl bg-blue-50 text-2xl">
                    👨‍🎓
                </div>

            </div>

        </div>


        
        <div class="rounded-2xl border border-slate-200 bg-white
                    p-5 shadow-sm transition hover:-translate-y-0.5
                    hover:shadow-md">

            <div class="flex items-start justify-between">

                <div>

                    <p class="text-sm font-medium text-slate-500">
                        Teachers / Staff
                    </p>

                    <h2 class="mt-2 text-3xl font-bold text-slate-900">
                        <?php echo e(number_format($totalTeachers)); ?>

                    </h2>

                    <p class="mt-2 text-xs font-medium text-green-600">
                        <?php echo e(number_format($activeTeachers)); ?> Active
                    </p>

                </div>

                <div class="flex h-12 w-12 items-center justify-center
                            rounded-xl bg-purple-50 text-2xl">
                    👨‍🏫
                </div>

            </div>

        </div>


        
        <div class="rounded-2xl border border-slate-200 bg-white
                    p-5 shadow-sm transition hover:-translate-y-0.5
                    hover:shadow-md">

            <div class="flex items-start justify-between">

                <div>

                    <p class="text-sm font-medium text-slate-500">
                        Classes
                    </p>

                    <h2 class="mt-2 text-3xl font-bold text-slate-900">
                        <?php echo e(number_format($totalClasses)); ?>

                    </h2>

                    <p class="mt-2 text-xs text-slate-500">
                        <?php echo e(number_format($totalSections)); ?> Sections
                    </p>

                </div>

                <div class="flex h-12 w-12 items-center justify-center
                            rounded-xl bg-amber-50 text-2xl">
                    📚
                </div>

            </div>

        </div>


        
        <div class="rounded-2xl border border-slate-200 bg-white
                    p-5 shadow-sm transition hover:-translate-y-0.5
                    hover:shadow-md">

            <div class="flex items-start justify-between">

                <div>

                    <p class="text-sm font-medium text-slate-500">
                        Subjects
                    </p>

                    <h2 class="mt-2 text-3xl font-bold text-slate-900">
                        <?php echo e(number_format($totalSubjects)); ?>

                    </h2>

                    <p class="mt-2 text-xs text-slate-500">
                        Active subjects
                    </p>

                </div>

                <div class="flex h-12 w-12 items-center justify-center
                            rounded-xl bg-green-50 text-2xl">
                    📖
                </div>

            </div>

        </div>

    </div>


    

    <div class="grid grid-cols-1 gap-6 xl:grid-cols-2">

        
        <div class="rounded-2xl border border-slate-200
                    bg-white shadow-sm">

            <div class="flex items-center justify-between
                        border-b border-slate-100 px-5 py-4">

                <div>

                    <h2 class="font-bold text-slate-900">
                        Student Attendance
                    </h2>

                    <p class="mt-1 text-xs text-slate-500">
                        Today's attendance summary
                    </p>

                </div>

                <span class="rounded-lg bg-blue-50 px-3 py-1.5
                             text-xs font-semibold text-blue-700">
                    Today
                </span>

            </div>


            <div class="grid grid-cols-2 gap-4 p-5 sm:grid-cols-4">

                <div class="rounded-xl bg-green-50 p-4 text-center">
                    <p class="text-2xl font-bold text-green-700">
                        <?php echo e(number_format($todayStudentAttendance['present'])); ?>

                    </p>

                    <p class="mt-1 text-xs font-semibold text-green-600">
                        Present
                    </p>
                </div>


                <div class="rounded-xl bg-red-50 p-4 text-center">
                    <p class="text-2xl font-bold text-red-700">
                        <?php echo e(number_format($todayStudentAttendance['absent'])); ?>

                    </p>

                    <p class="mt-1 text-xs font-semibold text-red-600">
                        Absent
                    </p>
                </div>


                <div class="rounded-xl bg-amber-50 p-4 text-center">
                    <p class="text-2xl font-bold text-amber-700">
                        <?php echo e(number_format($todayStudentAttendance['late'])); ?>

                    </p>

                    <p class="mt-1 text-xs font-semibold text-amber-600">
                        Late
                    </p>
                </div>


                <div class="rounded-xl bg-purple-50 p-4 text-center">
                    <p class="text-2xl font-bold text-purple-700">
                        <?php echo e(number_format($todayStudentAttendance['leave'])); ?>

                    </p>

                    <p class="mt-1 text-xs font-semibold text-purple-600">
                        Leave
                    </p>
                </div>

            </div>

        </div>


        
        <div class="rounded-2xl border border-slate-200
                    bg-white shadow-sm">

            <div class="flex items-center justify-between
                        border-b border-slate-100 px-5 py-4">

                <div>

                    <h2 class="font-bold text-slate-900">
                        Teacher Attendance
                    </h2>

                    <p class="mt-1 text-xs text-slate-500">
                        Today's attendance summary
                    </p>

                </div>

                <span class="rounded-lg bg-purple-50 px-3 py-1.5
                             text-xs font-semibold text-purple-700">
                    Today
                </span>

            </div>


            <div class="grid grid-cols-2 gap-4 p-5 sm:grid-cols-4">

                <div class="rounded-xl bg-green-50 p-4 text-center">
                    <p class="text-2xl font-bold text-green-700">
                        <?php echo e(number_format($todayTeacherAttendance['present'])); ?>

                    </p>

                    <p class="mt-1 text-xs font-semibold text-green-600">
                        Present
                    </p>
                </div>


                <div class="rounded-xl bg-red-50 p-4 text-center">
                    <p class="text-2xl font-bold text-red-700">
                        <?php echo e(number_format($todayTeacherAttendance['absent'])); ?>

                    </p>

                    <p class="mt-1 text-xs font-semibold text-red-600">
                        Absent
                    </p>
                </div>


                <div class="rounded-xl bg-amber-50 p-4 text-center">
                    <p class="text-2xl font-bold text-amber-700">
                        <?php echo e(number_format($todayTeacherAttendance['late'])); ?>

                    </p>

                    <p class="mt-1 text-xs font-semibold text-amber-600">
                        Late
                    </p>
                </div>


                <div class="rounded-xl bg-purple-50 p-4 text-center">
                    <p class="text-2xl font-bold text-purple-700">
                        <?php echo e(number_format($todayTeacherAttendance['leave'])); ?>

                    </p>

                    <p class="mt-1 text-xs font-semibold text-purple-600">
                        Leave
                    </p>
                </div>

            </div>

        </div>

    </div>


    

    <div class="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">

        
        <div class="rounded-2xl border border-slate-200
                    bg-white p-5 shadow-sm">

            <div class="flex items-center gap-4">

                <div class="flex h-12 w-12 items-center justify-center
                            rounded-xl bg-green-50 text-2xl">
                    💰
                </div>

                <div>

                    <p class="text-sm text-slate-500">
                        Today's Collection
                    </p>

                    <h2 class="mt-1 text-2xl font-bold text-slate-900">
                        ৳ <?php echo e(number_format($todayCollection, 2)); ?>

                    </h2>

                </div>

            </div>

        </div>


        
        <div class="rounded-2xl border border-slate-200
                    bg-white p-5 shadow-sm">

            <div class="flex items-center gap-4">

                <div class="flex h-12 w-12 items-center justify-center
                            rounded-xl bg-blue-50 text-2xl">
                    💳
                </div>

                <div>

                    <p class="text-sm text-slate-500">
                        Total Collection
                    </p>

                    <h2 class="mt-1 text-2xl font-bold text-slate-900">
                        ৳ <?php echo e(number_format($totalCollection, 2)); ?>

                    </h2>

                </div>

            </div>

        </div>


        
        <div class="rounded-2xl border border-slate-200
                    bg-white p-5 shadow-sm">

            <div class="flex items-center gap-4">

                <div class="flex h-12 w-12 items-center justify-center
                            rounded-xl bg-red-50 text-2xl">
                    ⚠️
                </div>

                <div>

                    <p class="text-sm text-slate-500">
                        Total Due
                    </p>

                    <h2 class="mt-1 text-2xl font-bold text-red-600">

                    </h2>

                </div>

            </div>

        </div>

    </div>


    

    <div class="grid grid-cols-1 gap-6 xl:grid-cols-2">


        
        <div class="overflow-hidden rounded-2xl border border-slate-200
                    bg-white shadow-sm">

            <div class="flex items-center justify-between
                        border-b border-slate-100 px-5 py-4">

                <div>

                    <h2 class="font-bold text-slate-900">
                        Recent Students
                    </h2>

                    <p class="mt-1 text-xs text-slate-500">
                        Recently added students
                    </p>

                </div>

                <a href="<?php echo e(route('admin.students.index')); ?>"
                    class="text-xs font-semibold text-blue-600 hover:text-blue-700">
                    View All →
                </a>

            </div>


            <div class="divide-y divide-slate-100">
                <?php $__empty_1 = true; $__currentLoopData = $recentStudents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="flex items-center gap-3 px-5 py-4">
                    <div class="flex h-10 w-10 shrink-0 items-center  justify-center rounded-full bg-blue-50  font-bold text-blue-600">
                        <?php echo e(strtoupper(substr($student->name ?? 'S', 0, 1))); ?>

                    </div>
                    <div class="min-w-0 flex-1">
                        <p class="truncate text-sm font-semibold text-slate-900">
                            <?php echo e($student->name ?? 'Student'); ?>

                        </p>
                        <p class="mt-0.5 text-xs text-slate-500">
                            ID:
                            <?php echo e($student->student_id ?? $student->id); ?>

                        </p>
                    </div>
                    <span class="text-xs text-slate-400">
                        <?php echo e($student->created_at?->format('d M')); ?>

                    </span>
                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="px-5 py-10 text-center">
                    <p class="text-sm text-slate-500">
                        No students found.
                    </p>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="overflow-hidden rounded-2xl border border-slate-200  bg-white shadow-sm">
            <div class="flex items-center justify-between border-b border-slate-100 px-5 py-4">
                <div>
                    <h2 class="font-bold text-slate-900">
                        Recent Payments
                    </h2>
                    <p class="mt-1 text-xs text-slate-500">
                        Latest fee collections
                    </p>
                </div>
                <a href="#" class="text-xs font-semibold text-blue-600 hover:text-blue-700">
                    View All →
                </a>
            </div>


            <div class="divide-y divide-slate-100">
                <?php $__empty_1 = true; $__currentLoopData = $recentPayments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="flex items-center gap-3 px-5 py-4">
                    <div class="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-green-50 text-green-600">
                        ৳
                    </div>
                    <div class="min-w-0 flex-1">
                        <p class="text-sm font-semibold text-slate-900">
                            Fee Payment
                        </p>
                        <p class="mt-0.5 text-xs text-slate-500">
                            <?php echo e($payment->payment_date
                            ? \Carbon\Carbon::parse($payment->payment_date)->format('d M Y')
                            : $payment->created_at?->format('d M Y')); ?>

                        </p>
                    </div>
                    <p class="text-sm font-bold text-green-600">
                        ৳ <?php echo e(number_format($payment->amount ?? 0, 2)); ?>

                    </p>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="px-5 py-10 text-center">
                    <p class="text-sm text-slate-500">
                        No payments found.
                    </p>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    

    <div class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6">
        <div class="mb-5">
            <h2 class="font-bold text-slate-900">
                Quick Actions
            </h2>
            <p class="mt-1 text-xs text-slate-500">
                Frequently used modules
            </p>
        </div>
        <div class="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
            
            <a href="<?php echo e(route('admin.students.create')); ?>" class="group rounded-xl border border-slate-200
                       p-4 text-center transition hover:border-blue-300
                       hover:bg-blue-50">
                <div class="text-2xl">
                    👨‍🎓
                </div>
                <p class="mt-2 text-xs font-semibold text-slate-700
                          group-hover:text-blue-700">
                    Add Student
                </p>
            </a>
            
            <a href="<?php echo e(route('admin.academic.class-subjects.create')); ?>" class="group rounded-xl border border-slate-200
                       p-4 text-center transition hover:border-blue-300
                       hover:bg-blue-50">
                <div class="text-2xl">
                    📚
                </div>
                <p class="mt-2 text-xs font-semibold text-slate-700 group-hover:text-blue-700"> Assign Subject </p>
            </a>
            
            <a href="<?php echo e(route('admin.academic.subjects.create')); ?>" class="group rounded-xl border border-slate-200
                       p-4 text-center transition hover:border-blue-300
                       hover:bg-blue-50">
                <div class="text-2xl">
                    📖
                </div>
                <p class="mt-2 text-xs font-semibold text-slate-700 group-hover:text-blue-700">
                    Add Subject
                </p>
            </a>
            
            <a href="<?php echo e(route('admin.academic.classes.create')); ?>" class="group rounded-xl border border-slate-200  p-4 text-center transition hover:border-blue-300 hover:bg-blue-50">
                <div class="text-2xl">
                    🏫
                </div>
                <p class="mt-2 text-xs font-semibold text-slate-700
                          group-hover:text-blue-700">
                    Add Class
                </p>
            </a>
            
            <a href="<?php echo e(route('admin.academic.sections.create')); ?>" class="group rounded-xl border border-slate-200
                       p-4 text-center transition hover:border-blue-300
                       hover:bg-blue-50">
                <div class="text-2xl">
                    🧑‍🤝‍🧑
                </div>
                <p class="mt-2 text-xs font-semibold text-slate-700
                          group-hover:text-blue-700">
                    Add Section
                </p>
            </a>
            
            <a href="<?php echo e(route('dashboard')); ?>" class="group rounded-xl border border-slate-200 p-4 text-center transition hover:border-blue-300  hover:bg-blue-50">
                <div class="text-2xl">
                    📊
                </div>
                <p class="mt-2 text-xs font-semibold text-slate-700 group-hover:text-blue-700">
                    Dashboard
                </p>
            </a>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\school-management\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>