

<?php $__env->startSection('title', 'Departments'); ?>
<?php $__env->startSection('page-title', 'Departments'); ?>

<?php $__env->startSection('content'); ?>

<div class="max-w-screen-2xl mx-auto px-3 sm:px-4 lg:px-6 py-4 sm:py-6">

    
    <div class="mb-6">
        <div class="flex flex-col sm:flex-row
                    sm:items-center sm:justify-between gap-4">

            <div>
                <h1 class="text-xl sm:text-2xl font-bold text-slate-800">
                    Departments
                </h1>

                <p class="mt-1 text-xs sm:text-sm text-slate-500">
                    Manage teacher and staff departments
                </p>
            </div>

            <a href="<?php echo e(route('admin.departments.create')); ?>"
               class="inline-flex items-center justify-center gap-2
                      rounded-lg bg-blue-600 px-4 py-2.5
                      text-sm font-semibold text-white
                      hover:bg-blue-700 transition">

                <i class="bi bi-plus-lg"></i>

                Add Department
            </a>

        </div>
    </div>


    
    <?php if(session('success')): ?>

        <div class="mb-5 rounded-lg border border-green-200
                    bg-green-50 px-4 py-3">

            <div class="flex items-center gap-3">

                <div class="flex h-8 w-8 items-center justify-center
                            rounded-full bg-green-100 text-green-600">

                    <i class="bi bi-check-lg"></i>

                </div>

                <div>
                    <p class="text-sm font-semibold text-green-800">
                        Success
                    </p>

                    <p class="text-sm text-green-700">
                        <?php echo e(session('success')); ?>

                    </p>
                </div>

            </div>

        </div>

    <?php endif; ?>


    
    <div class="bg-white rounded-xl border border-slate-200
                shadow-sm overflow-hidden">

        <div class="px-4 sm:px-5 py-4 border-b border-slate-200">

            <h2 class="font-semibold text-slate-800">
                Department List
            </h2>

            <p class="mt-1 text-xs text-slate-500">
                All departments available in your branch
            </p>

        </div>


        <div class="overflow-x-auto">

            <table class="w-full text-sm">

                <thead class="bg-slate-50 border-b border-slate-200">

                    <tr>

                        <th class="px-4 py-3 text-left
                                   font-semibold text-slate-600">
                            #
                        </th>

                        <th class="px-4 py-3 text-left
                                   font-semibold text-slate-600">
                            Department
                        </th>

                        <th class="px-4 py-3 text-left
                                   font-semibold text-slate-600">
                            Code
                        </th>

                        <th class="px-4 py-3 text-left
                                   font-semibold text-slate-600">
                            Branch
                        </th>

                        <th class="px-4 py-3 text-center
                                   font-semibold text-slate-600">
                            Status
                        </th>

                        <th class="px-4 py-3 text-right
                                   font-semibold text-slate-600">
                            Actions
                        </th>

                    </tr>

                </thead>


                <tbody class="divide-y divide-slate-100">

                    <?php $__empty_1 = true; $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                        <tr class="hover:bg-slate-50 transition">

                            
                            <td class="px-4 py-4 text-slate-500">
                                <?php echo e($departments->firstItem() + $loop->index); ?>

                            </td>


                            
                            <td class="px-4 py-4">

                                <div class="flex items-center gap-3">

                                    <div class="flex h-10 w-10 shrink-0
                                                items-center justify-center
                                                rounded-lg bg-blue-50
                                                text-blue-600">

                                        <i class="bi bi-diagram-3"></i>

                                    </div>

                                    <div>

                                        <p class="font-semibold text-slate-800">
                                            <?php echo e($department->name); ?>

                                        </p>

                                        <?php if($department->description): ?>

                                            <p class="text-xs text-slate-400
                                                      mt-0.5 max-w-xs truncate">

                                                <?php echo e($department->description); ?>


                                            </p>

                                        <?php endif; ?>

                                    </div>

                                </div>

                            </td>


                            
                            <td class="px-4 py-4">

                                <?php if($department->code): ?>

                                    <span class="inline-flex items-center
                                                 rounded-md bg-slate-100
                                                 px-2 py-1 text-xs
                                                 font-medium text-slate-600">

                                        <?php echo e($department->code); ?>


                                    </span>

                                <?php else: ?>

                                    <span class="text-slate-400">—</span>

                                <?php endif; ?>

                            </td>


                            
                            <td class="px-4 py-4 text-slate-700">

                                <?php echo e($department->branch->name ?? 'N/A'); ?>


                            </td>


                            
                            <td class="px-4 py-4 text-center">

                                <?php if($department->status): ?>

                                    <span class="inline-flex items-center gap-1.5
                                                 rounded-full bg-green-50
                                                 px-2.5 py-1 text-xs
                                                 font-medium text-green-700">

                                        <span class="h-1.5 w-1.5 rounded-full
                                                     bg-green-500"></span>

                                        Active

                                    </span>

                                <?php else: ?>

                                    <span class="inline-flex items-center gap-1.5
                                                 rounded-full bg-red-50
                                                 px-2.5 py-1 text-xs
                                                 font-medium text-red-700">

                                        <span class="h-1.5 w-1.5 rounded-full
                                                     bg-red-500"></span>

                                        Inactive

                                    </span>

                                <?php endif; ?>

                            </td>


                            
                            <td class="px-4 py-4">

                                <div class="flex items-center
                                            justify-end gap-2">

                                    
                                    <a href="<?php echo e(route(
                                        'admin.departments.edit',
                                        $department
                                    )); ?>"
                                       title="Edit"
                                       class="inline-flex h-9 w-9
                                              items-center justify-center
                                              rounded-lg border
                                              border-blue-200
                                              bg-blue-50
                                              text-blue-600
                                              hover:bg-blue-100 transition">

                                        <i class="bi bi-pencil-square"></i>

                                    </a>


                                    
                                    <form method="POST"
                                          action="<?php echo e(route(
                                              'admin.departments.destroy',
                                              $department
                                          )); ?>"
                                          onsubmit="return confirm(
                                              'Are you sure you want to delete this department?'
                                          )">

                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>

                                        <button type="submit"
                                                title="Delete"
                                                class="inline-flex h-9 w-9
                                                       items-center justify-center
                                                       rounded-lg border
                                                       border-red-200
                                                       bg-red-50
                                                       text-red-600
                                                       hover:bg-red-100 transition">

                                            <i class="bi bi-trash3"></i>

                                        </button>

                                    </form>

                                </div>

                            </td>

                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <tr>

                            <td colspan="6"
                                class="px-4 py-16 text-center">

                                <div class="flex flex-col items-center">

                                    <div class="flex h-16 w-16
                                                items-center justify-center
                                                rounded-full bg-blue-50
                                                text-blue-600">

                                        <i class="bi bi-diagram-3 text-3xl"></i>

                                    </div>

                                    <h3 class="mt-4 text-base
                                               font-semibold text-slate-700">

                                        No Departments Found

                                    </h3>

                                    <p class="mt-1 text-sm text-slate-500">

                                        Create your first department.

                                    </p>

                                    <a href="<?php echo e(route(
                                        'admin.departments.create'
                                    )); ?>"
                                       class="mt-5 inline-flex items-center
                                              gap-2 rounded-lg bg-blue-600
                                              px-4 py-2.5 text-sm
                                              font-semibold text-white
                                              hover:bg-blue-700 transition">

                                        <i class="bi bi-plus-lg"></i>

                                        Add Department

                                    </a>

                                </div>

                            </td>

                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>


        
        <?php if($departments->hasPages()): ?>

            <div class="px-4 py-4 border-t border-slate-200">

                <?php echo e($departments->links()); ?>


            </div>

        <?php endif; ?>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\school-management\resources\views/admin/departments/index.blade.php ENDPATH**/ ?>