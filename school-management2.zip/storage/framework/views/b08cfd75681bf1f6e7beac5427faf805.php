

<?php $__env->startSection('title', 'Leave Allocations'); ?>

<?php $__env->startSection('content'); ?>

<div class="space-y-6">

    
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">

        <div>
            <h1 class="text-2xl font-bold text-slate-800">
                Leave Allocations
            </h1>

            <p class="text-sm text-slate-500 mt-1">
                Manage teacher and staff leave allocations.
            </p>
        </div>

        <a href="<?php echo e(route('admin.leave-allocations.create')); ?>"
           class="inline-flex items-center justify-center gap-2 px-4 py-2.5
                  bg-blue-600 hover:bg-blue-700 text-white
                  rounded-lg text-sm font-medium transition">

            <i class="bi bi-plus-lg"></i>
            Allocate Leave

        </a>

    </div>


    
    <?php if(session('success')): ?>

        <div class="flex items-center gap-3 p-4
                    bg-green-50 border border-green-200
                    text-green-700 rounded-lg">

            <i class="bi bi-check-circle-fill"></i>

            <span class="text-sm font-medium">
                <?php echo e(session('success')); ?>

            </span>

        </div>

    <?php endif; ?>


    
    <div class="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">

        <div class="px-6 py-4 border-b border-slate-200
                    flex items-center justify-between">

            <div>
                <h2 class="text-base font-semibold text-slate-800">
                    Allocation List
                </h2>

                <p class="text-xs text-slate-500 mt-1">
                    Total: <?php echo e($leaveAllocations->total()); ?>

                </p>
            </div>

        </div>


        <div class="overflow-x-auto">

            <table class="w-full text-sm">

                <thead class="bg-slate-50 border-b border-slate-200">

                    <tr>

                        <th class="px-6 py-3 text-left font-semibold text-slate-600">
                            #
                        </th>

                        <th class="px-6 py-3 text-left font-semibold text-slate-600">
                            Teacher / Staff
                        </th>

                        <th class="px-6 py-3 text-left font-semibold text-slate-600">
                            Leave Type
                        </th>

                        <th class="px-6 py-3 text-left font-semibold text-slate-600">
                            Academic Session
                        </th>

                        <th class="px-6 py-3 text-center font-semibold text-slate-600">
                            Allocated
                        </th>

                        <th class="px-6 py-3 text-center font-semibold text-slate-600">
                            Used
                        </th>

                        <th class="px-6 py-3 text-center font-semibold text-slate-600">
                            Remaining
                        </th>

                        <th class="px-6 py-3 text-center font-semibold text-slate-600">
                            Status
                        </th>

                        <th class="px-6 py-3 text-right font-semibold text-slate-600">
                            Action
                        </th>

                    </tr>

                </thead>


                <tbody class="divide-y divide-slate-100">

                    <?php $__empty_1 = true; $__currentLoopData = $leaveAllocations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allocation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                        <?php
                            $remaining =
                                $allocation->allocated_days -
                                $allocation->used_days;
                        ?>

                        <tr class="hover:bg-slate-50 transition">

                            
                            <td class="px-6 py-4 text-slate-500">
                                <?php echo e($leaveAllocations->firstItem() + $loop->index); ?>

                            </td>


                            
                            <td class="px-6 py-4">

                                <div class="font-medium text-slate-800">
                                    <?php echo e($allocation->teacherStaff->name ?? 'N/A'); ?>

                                </div>

                                <?php if($allocation->teacherStaff?->employee_id): ?>

                                    <div class="text-xs text-slate-500 mt-0.5">
                                        ID:
                                        <?php echo e($allocation->teacherStaff->employee_id); ?>

                                    </div>

                                <?php endif; ?>

                            </td>


                            
                            <td class="px-6 py-4">

                                <span class="inline-flex items-center
                                             px-2.5 py-1 rounded-md
                                             bg-blue-50 text-blue-700
                                             text-xs font-medium">

                                    <?php echo e($allocation->leaveType->name ?? 'N/A'); ?>


                                </span>

                            </td>


                            
                            <td class="px-6 py-4 text-slate-600">

                                <?php echo e($allocation->academicSession->name ?? 'N/A'); ?>


                            </td>


                            
                            <td class="px-6 py-4 text-center">

                                <span class="font-semibold text-slate-800">
                                    <?php echo e($allocation->allocated_days); ?>

                                </span>

                            </td>


                            
                            <td class="px-6 py-4 text-center">

                                <span class="font-semibold text-orange-600">
                                    <?php echo e($allocation->used_days); ?>

                                </span>

                            </td>


                            
                            <td class="px-6 py-4 text-center">

                                <span class="inline-flex items-center
                                    px-2.5 py-1 rounded-md
                                    <?php echo e($remaining > 0
                                        ? 'bg-green-50 text-green-700'
                                        : 'bg-red-50 text-red-700'); ?>

                                    text-xs font-semibold">

                                    <?php echo e($remaining); ?>


                                </span>

                            </td>


                            
                            <td class="px-6 py-4 text-center">

                                <?php if($allocation->status): ?>

                                    <span class="inline-flex items-center
                                                 px-2.5 py-1 rounded-full
                                                 bg-green-50 text-green-700
                                                 text-xs font-medium">

                                        <span class="w-1.5 h-1.5 mr-1.5
                                                     rounded-full bg-green-500"></span>

                                        Active

                                    </span>

                                <?php else: ?>

                                    <span class="inline-flex items-center
                                                 px-2.5 py-1 rounded-full
                                                 bg-red-50 text-red-700
                                                 text-xs font-medium">

                                        <span class="w-1.5 h-1.5 mr-1.5
                                                     rounded-full bg-red-500"></span>

                                        Inactive

                                    </span>

                                <?php endif; ?>

                            </td>


                            
                            <td class="px-6 py-4">

                                <div class="flex items-center justify-end gap-2">

                                    
                                    <a href="<?php echo e(route('admin.leave-allocations.edit', $allocation)); ?>"
                                       class="inline-flex items-center justify-center
                                              w-9 h-9 rounded-lg
                                              bg-blue-50 text-blue-600
                                              hover:bg-blue-100 transition"
                                       title="Edit">

                                        <i class="bi bi-pencil"></i>

                                    </a>


                                    
                                    <form action="<?php echo e(route('admin.leave-allocations.destroy', $allocation)); ?>"
                                          method="POST"
                                          onsubmit="return confirm('Are you sure you want to delete this leave allocation?');">

                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>

                                        <button type="submit"
                                                class="inline-flex items-center justify-center
                                                       w-9 h-9 rounded-lg
                                                       bg-red-50 text-red-600
                                                       hover:bg-red-100 transition"
                                                title="Delete">

                                            <i class="bi bi-trash"></i>

                                        </button>

                                    </form>

                                </div>

                            </td>

                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <tr>

                            <td colspan="9"
                                class="px-6 py-12 text-center">

                                <div class="flex flex-col items-center">

                                    <div class="w-12 h-12 rounded-full
                                                bg-slate-100 flex items-center
                                                justify-center mb-3">

                                        <i class="bi bi-calendar-x
                                                  text-xl text-slate-400"></i>

                                    </div>

                                    <h3 class="text-sm font-semibold text-slate-700">
                                        No Leave Allocations Found
                                    </h3>

                                    <p class="text-xs text-slate-500 mt-1">
                                        Start by allocating leave to a teacher or staff member.
                                    </p>

                                </div>

                            </td>

                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>


        
        <?php if($leaveAllocations->hasPages()): ?>

            <div class="px-6 py-4 border-t border-slate-200">
                <?php echo e($leaveAllocations->links()); ?>

            </div>

        <?php endif; ?>

    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\school-management\resources\views/admin/leave-allocations/index.blade.php ENDPATH**/ ?>