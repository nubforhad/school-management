<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>
        <?php echo $__env->yieldContent('title', 'Dashboard'); ?>  - <?php echo e(config('app.name')); ?>

    </title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css"
>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: {
                            50: '#eff6ff',
                            100: '#dbeafe',
                            500: '#3b82f6',
                            600: '#2563eb',
                            700: '#1d4ed8',
                            800: '#1e40af',
                            900: '#1e3a8a',
                        }
                    }
                }
            }
        }
    </script>

    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body class="bg-slate-100 text-slate-800">

    <div class="min-h-screen">

        
        <?php echo $__env->make('admin.layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        
        <div class="lg:ml-64">

            
            <?php echo $__env->make('admin.layouts.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <main class="p-4 sm:p-6 lg:p-8">
                <?php echo $__env->yieldContent('content'); ?>
            </main>

        </div>

    </div>

    <?php echo $__env->yieldPushContent('scripts'); ?>
<script>

function toggleNavGroup(button) {

    const submenu = button.nextElementSibling;
    const isOpen = !submenu.classList.contains('hidden');

    // Close all other groups
    document.querySelectorAll('.nav-submenu').forEach(menu => {
        menu.classList.add('hidden');
    });

    document.querySelectorAll('.nav-group-title').forEach(title => {
        title.classList.remove('active');
    });


    // Open selected group
    if (!isOpen) {

        submenu.classList.remove('hidden');

        button.classList.add('active');

    }

}

</script>
</body>
</html><?php /**PATH C:\xampp\htdocs\school-management\resources\views/admin/layouts/app.blade.php ENDPATH**/ ?>