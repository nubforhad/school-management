

<?php $__env->startSection('title', 'Exam Schedules'); ?>

<?php $__env->startSection('page-title', 'Exam Schedules'); ?>

<?php $__env->startSection('content'); ?>

<div class="max-w-screen-xl mx-auto px-3 sm:px-4 lg:px-6 py-4 sm:py-6">

    
    <div class="mb-6">
        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">

            <div>
                <div class="flex items-center gap-2 text-sm text-slate-500 mb-2">
                    <a href="<?php echo e(route('admin.exams.index')); ?>"
                       class="hover:text-blue-600 transition">
                        Exams
                    </a>

                    <svg class="w-4 h-4"
                         fill="none"
                         stroke="currentColor"
                         viewBox="0 0 24 24">
                        <path stroke-linecap="round"
                              stroke-linejoin="round"
                              stroke-width="2"
                              d="M9 5l7 7-7 7"/>
                    </svg>

                    <span class="text-slate-700">
                        Exam Schedules
                    </span>
                </div>

                <h1 class="text-2xl sm:text-3xl font-bold text-slate-800">
                    Exam Schedules
                </h1>

                <p class="text-sm text-slate-500 mt-1">
                    Manage examination dates, subjects, rooms and timings.
                </p>
            </div>

            <a href="<?php echo e(route('admin.exam-schedules.create')); ?>"
               class="inline-flex items-center justify-center gap-2
                      px-4 py-2.5 rounded-lg
                      bg-blue-600 hover:bg-blue-700
                      text-white text-sm font-semibold
                      shadow-sm transition">

                <svg class="w-5 h-5"
                     fill="none"
                     stroke="currentColor"
                     viewBox="0 0 24 24">
                    <path stroke-linecap="round"
                          stroke-linejoin="round"
                          stroke-width="2"
                          d="M12 4v16m8-8H4"/>
                </svg>

                Add Schedule
            </a>

        </div>
    </div>


    
    <?php if(session('success')): ?>
        <div class="mb-5 flex items-start gap-3
                    rounded-lg border border-green-200
                    bg-green-50 px-4 py-3">

            <svg class="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0"
                 fill="none"
                 stroke="currentColor"
                 viewBox="0 0 24 24">
                <path stroke-linecap="round"
                      stroke-linejoin="round"
                      stroke-width="2"
                      d="M5 13l4 4L19 7"/>
            </svg>

            <div class="text-sm text-green-700">
                <?php echo e(session('success')); ?>

            </div>
        </div>
    <?php endif; ?>


    
    <?php if(session('error')): ?>
        <div class="mb-5 flex items-start gap-3
                    rounded-lg border border-red-200
                    bg-red-50 px-4 py-3">

            <svg class="w-5 h-5 text-red-600 mt-0.5 flex-shrink-0"
                 fill="none"
                 stroke="currentColor"
                 viewBox="0 0 24 24">
                <path stroke-linecap="round"
                      stroke-linejoin="round"
                      stroke-width="2"
                      d="M6 18L18 6M6 6l12 12"/>
            </svg>

            <div class="text-sm text-red-700">
                <?php echo e(session('error')); ?>

            </div>
        </div>
    <?php endif; ?>


    
    <div class="bg-white border border-slate-200 rounded-xl shadow-sm mb-6">

        <div class="px-4 sm:px-5 py-4 border-b border-slate-200 bg-slate-50 rounded-t-xl">

            <div class="flex items-center gap-2">

                <div class="w-8 h-8 rounded-lg bg-blue-50
                            flex items-center justify-center">

                    <svg class="w-4 h-4 text-blue-600"
                         fill="none"
                         stroke="currentColor"
                         viewBox="0 0 24 24">
                        <path stroke-linecap="round"
                              stroke-linejoin="round"
                              stroke-width="2"
                              d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2a1 1 0 01-.293.707L14 12.414V19a1 1 0 01-.553.894l-4 2A1 1 0 018 21v-8.586L3.293 6.707A1 1 0 013 6V4z"/>
                    </svg>

                </div>

                <h2 class="font-semibold text-slate-800">
                    Filter Schedules
                </h2>

            </div>
        </div>


        <form method="GET"
              action="<?php echo e(route('admin.exam-schedules.index')); ?>"
              class="p-4 sm:p-5">

            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">

                
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-1.5">
                        Exam
                    </label>

                    <select name="exam_id"
                            class="w-full rounded-lg border-slate-300
                                   focus:border-blue-500 focus:ring-blue-500
                                   text-sm">

                        <option value="">All Exams</option>

                        <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($exam->id); ?>"
                                <?php echo e(request('exam_id') == $exam->id ? 'selected' : ''); ?>>
                                <?php echo e($exam->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>
                </div>


                
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-1.5">
                        Academic Session
                    </label>

                    <select name="academic_session_id"
                            class="w-full rounded-lg border-slate-300
                                   focus:border-blue-500 focus:ring-blue-500
                                   text-sm">

                        <option value="">All Sessions</option>

                        <?php $__currentLoopData = $academicSessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($session->id); ?>"
                                <?php echo e(request('academic_session_id') == $session->id ? 'selected' : ''); ?>>
                                <?php echo e($session->name ?? $session->title ?? $session->year ?? 'Session '.$session->id); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>
                </div>


                
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-1.5">
                        Class
                    </label>

                    <select name="school_class_id"
                            class="w-full rounded-lg border-slate-300
                                   focus:border-blue-500 focus:ring-blue-500
                                   text-sm">

                        <option value="">All Classes</option>

                        <?php $__currentLoopData = $schoolClasses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($class->id); ?>"
                                <?php echo e(request('school_class_id') == $class->id ? 'selected' : ''); ?>>
                                <?php echo e($class->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>
                </div>


                
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-1.5">
                        Exam Date
                    </label>

                    <input type="date"
                           name="exam_date"
                           value="<?php echo e(request('exam_date')); ?>"
                           class="w-full rounded-lg border-slate-300
                                  focus:border-blue-500 focus:ring-blue-500
                                  text-sm">
                </div>


                
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-1.5">
                        Status
                    </label>

                    <select name="status"
                            class="w-full rounded-lg border-slate-300
                                   focus:border-blue-500 focus:ring-blue-500
                                   text-sm">

                        <option value="">All Status</option>

                        <option value="1"
                            <?php echo e(request('status') === '1' ? 'selected' : ''); ?>>
                            Active
                        </option>

                        <option value="0"
                            <?php echo e(request('status') === '0' ? 'selected' : ''); ?>>
                            Inactive
                        </option>

                    </select>
                </div>

            </div>


            
            <div class="flex flex-wrap items-center gap-2 mt-4">

                <button type="submit"
                        class="inline-flex items-center gap-2
                               px-4 py-2 rounded-lg
                               bg-blue-600 hover:bg-blue-700
                               text-white text-sm font-medium
                               transition">

                    <svg class="w-4 h-4"
                         fill="none"
                         stroke="currentColor"
                         viewBox="0 0 24 24">
                        <path stroke-linecap="round"
                              stroke-linejoin="round"
                              stroke-width="2"
                              d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2a1 1 0 01-.293.707L14 12.414V19a1 1 0 01-.553.894l-4 2A1 1 0 018 21v-8.586L3.293 6.707A1 1 0 013 6V4z"/>
                    </svg>

                    Filter
                </button>


                <a href="<?php echo e(route('admin.exam-schedules.index')); ?>"
                   class="inline-flex items-center gap-2
                          px-4 py-2 rounded-lg
                          border border-slate-300
                          bg-white hover:bg-slate-50
                          text-slate-700 text-sm font-medium
                          transition">

                    Reset
                </a>

            </div>

        </form>

    </div>


    
    <div class="hidden lg:block bg-white border border-slate-200
                rounded-xl shadow-sm overflow-hidden">

        <div class="px-5 py-4 border-b border-slate-200 bg-slate-50">

            <div class="flex items-center justify-between">

                <div>
                    <h2 class="font-semibold text-slate-800">
                        Schedule List
                    </h2>

                    <p class="text-xs text-slate-500 mt-0.5">
                        <?php echo e($schedules->total()); ?> schedule(s) found
                    </p>
                </div>

            </div>

        </div>


        <div class="overflow-x-auto">

            <table class="w-full text-sm">

                <thead class="bg-slate-50 border-b border-slate-200">

                    <tr>

                        <th class="px-5 py-3 text-left font-semibold text-slate-600">
                            #
                        </th>

                        <th class="px-5 py-3 text-left font-semibold text-slate-600">
                            Exam
                        </th>

                        <th class="px-5 py-3 text-left font-semibold text-slate-600">
                            Class / Section
                        </th>

                        <th class="px-5 py-3 text-left font-semibold text-slate-600">
                            Subject
                        </th>

                        <th class="px-5 py-3 text-left font-semibold text-slate-600">
                            Date
                        </th>

                        <th class="px-5 py-3 text-left font-semibold text-slate-600">
                            Time
                        </th>

                        <th class="px-5 py-3 text-left font-semibold text-slate-600">
                            Room
                        </th>

                        <th class="px-5 py-3 text-center font-semibold text-slate-600">
                            Status
                        </th>

                        <th class="px-5 py-3 text-right font-semibold text-slate-600">
                            Action
                        </th>

                    </tr>

                </thead>


                <tbody class="divide-y divide-slate-100">

                    <?php $__empty_1 = true; $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                        <tr class="hover:bg-slate-50 transition">

                            
                            <td class="px-5 py-4 text-slate-500">
                                <?php echo e($schedules->firstItem() + $index); ?>

                            </td>


                            
                            <td class="px-5 py-4">

                                <div class="font-semibold text-slate-800">
                                    <?php echo e($schedule->exam?->name ?? 'N/A'); ?>

                                </div>

                                <?php if($schedule->exam?->code): ?>
                                    <div class="text-xs text-slate-500 mt-0.5">
                                        <?php echo e($schedule->exam->code); ?>

                                    </div>
                                <?php endif; ?>

                            </td>


                            
                            <td class="px-5 py-4">

                                <div class="font-medium text-slate-700">
                                    <?php echo e($schedule->schoolClass?->name ?? 'N/A'); ?>

                                </div>

                                <?php if($schedule->section): ?>
                                    <div class="text-xs text-slate-500 mt-0.5">
                                        Section: <?php echo e($schedule->section->name); ?>

                                    </div>
                                <?php endif; ?>

                            </td>


                            
                            <td class="px-5 py-4">

                                <div class="font-medium text-slate-700">
                                    <?php echo e($schedule->subject?->name ?? 'N/A'); ?>

                                </div>

                            </td>


                            
                            <td class="px-5 py-4">

                                <div class="font-medium text-slate-700">
                                    <?php echo e($schedule->exam_date?->format('d M Y')); ?>

                                </div>

                            </td>


                            
                            <td class="px-5 py-4">

                                <div class="text-slate-700 whitespace-nowrap">

                                    <?php echo e(\Carbon\Carbon::parse($schedule->start_time)->format('h:i A')); ?>


                                    <span class="text-slate-400 mx-1">
                                        -
                                    </span>

                                    <?php echo e(\Carbon\Carbon::parse($schedule->end_time)->format('h:i A')); ?>


                                </div>

                            </td>


                            
                            <td class="px-5 py-4">

                                <?php if($schedule->room): ?>
                                    <span class="inline-flex items-center
                                                 px-2.5 py-1 rounded-md
                                                 bg-slate-100 text-slate-700
                                                 text-xs font-medium">

                                        <?php echo e($schedule->room); ?>


                                    </span>
                                <?php else: ?>
                                    <span class="text-slate-400">
                                        —
                                    </span>
                                <?php endif; ?>

                            </td>


                            
                            <td class="px-5 py-4 text-center">

                                <?php if($schedule->status): ?>

                                    <span class="inline-flex items-center
                                                 px-2.5 py-1 rounded-full
                                                 bg-green-50 text-green-700
                                                 border border-green-200
                                                 text-xs font-semibold">

                                        Active

                                    </span>

                                <?php else: ?>

                                    <span class="inline-flex items-center
                                                 px-2.5 py-1 rounded-full
                                                 bg-red-50 text-red-700
                                                 border border-red-200
                                                 text-xs font-semibold">

                                        Inactive

                                    </span>

                                <?php endif; ?>

                            </td>


                            
                            <td class="px-5 py-4">

                                <div class="flex items-center justify-end gap-1.5">

                                    
                                    <a href="<?php echo e(route('admin.exam-schedules.show', $schedule)); ?>"
                                       title="View"
                                       class="inline-flex items-center justify-center
                                              w-9 h-9 rounded-lg
                                              bg-blue-50 text-blue-600
                                              hover:bg-blue-100
                                              transition">

                                        <svg class="w-4 h-4"
                                             fill="none"
                                             stroke="currentColor"
                                             viewBox="0 0 24 24">
                                            <path stroke-linecap="round"
                                                  stroke-linejoin="round"
                                                  stroke-width="2"
                                                  d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                                            <path stroke-linecap="round"
                                                  stroke-linejoin="round"
                                                  stroke-width="2"
                                                  d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                                        </svg>

                                    </a>


                                    
                                    <a href="<?php echo e(route('admin.exam-schedules.edit', $schedule)); ?>"
                                       title="Edit"
                                       class="inline-flex items-center justify-center
                                              w-9 h-9 rounded-lg
                                              bg-amber-50 text-amber-600
                                              hover:bg-amber-100
                                              transition">

                                        <svg class="w-4 h-4"
                                             fill="none"
                                             stroke="currentColor"
                                             viewBox="0 0 24 24">
                                            <path stroke-linecap="round"
                                                  stroke-linejoin="round"
                                                  stroke-width="2"
                                                  d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5"/>
                                            <path stroke-linecap="round"
                                                  stroke-linejoin="round"
                                                  stroke-width="2"
                                                  d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/>
                                        </svg>

                                    </a>


                                    
                                    <form action="<?php echo e(route('admin.exam-schedules.destroy', $schedule)); ?>"
                                          method="POST"
                                          onsubmit="return confirm('Are you sure you want to delete this exam schedule?');">

                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>

                                        <button type="submit"
                                                title="Delete"
                                                class="inline-flex items-center justify-center
                                                       w-9 h-9 rounded-lg
                                                       bg-red-50 text-red-600
                                                       hover:bg-red-100
                                                       transition">

                                            <svg class="w-4 h-4"
                                                 fill="none"
                                                 stroke="currentColor"
                                                 viewBox="0 0 24 24">
                                                <path stroke-linecap="round"
                                                      stroke-linejoin="round"
                                                      stroke-width="2"
                                                      d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                                            </svg>

                                        </button>

                                    </form>

                                </div>

                            </td>

                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <tr>

                            <td colspan="9"
                                class="px-5 py-12 text-center">

                                <div class="flex flex-col items-center">

                                    <div class="w-14 h-14 rounded-full
                                                bg-slate-100
                                                flex items-center justify-center mb-3">

                                        <svg class="w-7 h-7 text-slate-400"
                                             fill="none"
                                             stroke="currentColor"
                                             viewBox="0 0 24 24">
                                            <path stroke-linecap="round"
                                                  stroke-linejoin="round"
                                                  stroke-width="2"
                                                  d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                                        </svg>

                                    </div>

                                    <h3 class="text-sm font-semibold text-slate-700">
                                        No exam schedules found
                                    </h3>

                                    <p class="text-xs text-slate-500 mt-1">
                                        Create your first exam schedule.
                                    </p>

                                    <a href="<?php echo e(route('admin.exam-schedules.create')); ?>"
                                       class="mt-4 inline-flex items-center gap-2
                                              px-4 py-2 rounded-lg
                                              bg-blue-600 hover:bg-blue-700
                                              text-white text-sm font-medium">

                                        Add Schedule

                                    </a>

                                </div>

                            </td>

                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>


        
        <?php if($schedules->hasPages()): ?>

            <div class="px-5 py-4 border-t border-slate-200">
                <?php echo e($schedules->links()); ?>

            </div>

        <?php endif; ?>

    </div>


    
    <div class="lg:hidden space-y-4">

        <div class="bg-white border border-slate-200
                    rounded-xl shadow-sm px-4 py-4">

            <div class="flex items-center justify-between">

                <div>
                    <h2 class="font-semibold text-slate-800">
                        Schedule List
                    </h2>

                    <p class="text-xs text-slate-500 mt-0.5">
                        <?php echo e($schedules->total()); ?> schedule(s) found
                    </p>
                </div>

                <div class="w-9 h-9 rounded-lg bg-blue-50
                            flex items-center justify-center">

                    <svg class="w-5 h-5 text-blue-600"
                         fill="none"
                         stroke="currentColor"
                         viewBox="0 0 24 24">
                        <path stroke-linecap="round"
                              stroke-linejoin="round"
                              stroke-width="2"
                              d="M8 7V3m8 4V3m-9 4h10m-9 4h10m-9 4h10m-9 4h10"/>
                    </svg>

                </div>

            </div>

        </div>


        <?php $__empty_1 = true; $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

            <div class="bg-white border border-slate-200
                        rounded-xl shadow-sm overflow-hidden">

                
                <div class="px-4 py-4 bg-slate-50
                            border-b border-slate-200">

                    <div class="flex items-start justify-between gap-3">

                        <div class="min-w-0">

                            <div class="text-xs text-slate-500 mb-1">
                                Schedule #<?php echo e($schedules->firstItem() + $index); ?>

                            </div>

                            <h3 class="font-bold text-slate-800 truncate">
                                <?php echo e($schedule->exam?->name ?? 'N/A'); ?>

                            </h3>

                            <?php if($schedule->exam?->code): ?>
                                <div class="text-xs text-slate-500 mt-1">
                                    <?php echo e($schedule->exam->code); ?>

                                </div>
                            <?php endif; ?>

                        </div>


                        <?php if($schedule->status): ?>

                            <span class="flex-shrink-0 inline-flex
                                         px-2.5 py-1 rounded-full
                                         bg-green-50 text-green-700
                                         border border-green-200
                                         text-xs font-semibold">

                                Active

                            </span>

                        <?php else: ?>

                            <span class="flex-shrink-0 inline-flex
                                         px-2.5 py-1 rounded-full
                                         bg-red-50 text-red-700
                                         border border-red-200
                                         text-xs font-semibold">

                                Inactive

                            </span>

                        <?php endif; ?>

                    </div>

                </div>


                
                <div class="px-4 py-4 space-y-3">

                    
                    <div class="flex items-start justify-between gap-4">

                        <span class="text-xs text-slate-500">
                            Class
                        </span>

                        <div class="text-right">

                            <div class="text-sm font-medium text-slate-700">
                                <?php echo e($schedule->schoolClass?->name ?? 'N/A'); ?>

                            </div>

                            <?php if($schedule->section): ?>
                                <div class="text-xs text-slate-500 mt-0.5">
                                    Section: <?php echo e($schedule->section->name); ?>

                                </div>
                            <?php endif; ?>

                        </div>

                    </div>


                    
                    <div class="flex items-start justify-between gap-4">

                        <span class="text-xs text-slate-500">
                            Subject
                        </span>

                        <span class="text-sm font-medium text-slate-700 text-right">
                            <?php echo e($schedule->subject?->name ?? 'N/A'); ?>

                        </span>

                    </div>


                    
                    <div class="flex items-center justify-between gap-4">

                        <span class="text-xs text-slate-500">
                            Exam Date
                        </span>

                        <span class="text-sm font-medium text-slate-700">
                            <?php echo e($schedule->exam_date?->format('d M Y')); ?>

                        </span>

                    </div>


                    
                    <div class="flex items-center justify-between gap-4">

                        <span class="text-xs text-slate-500">
                            Time
                        </span>

                        <span class="text-sm font-medium text-slate-700 text-right">
                            <?php echo e(\Carbon\Carbon::parse($schedule->start_time)->format('h:i A')); ?>

                            -
                            <?php echo e(\Carbon\Carbon::parse($schedule->end_time)->format('h:i A')); ?>

                        </span>

                    </div>


                    
                    <div class="flex items-center justify-between gap-4">

                        <span class="text-xs text-slate-500">
                            Room
                        </span>

                        <span class="text-sm font-medium text-slate-700">
                            <?php echo e($schedule->room ?: '—'); ?>

                        </span>

                    </div>


                    
                    <div class="flex items-center justify-between gap-4">

                        <span class="text-xs text-slate-500">
                            Marks
                        </span>

                        <span class="text-sm font-medium text-slate-700">
                            <?php echo e(rtrim(rtrim(number_format((float) $schedule->full_marks, 2), '0'), '.')); ?>


                            <?php if($schedule->pass_marks !== null): ?>
                                <span class="text-xs text-slate-400">
                                    / Pass
                                    <?php echo e(rtrim(rtrim(number_format((float) $schedule->pass_marks, 2), '0'), '.')); ?>

                                </span>
                            <?php endif; ?>
                        </span>

                    </div>

                </div>


                
                <div class="px-4 py-3 border-t border-slate-200
                            flex items-center justify-end gap-2">

                    <a href="<?php echo e(route('admin.exam-schedules.show', $schedule)); ?>"
                       class="inline-flex items-center gap-1.5
                              px-3 py-2 rounded-lg
                              bg-blue-50 text-blue-600
                              hover:bg-blue-100
                              text-xs font-semibold transition">

                        <svg class="w-4 h-4"
                             fill="none"
                             stroke="currentColor"
                             viewBox="0 0 24 24">
                            <path stroke-linecap="round"
                                  stroke-linejoin="round"
                                  stroke-width="2"
                                  d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                            <path stroke-linecap="round"
                                  stroke-linejoin="round"
                                  stroke-width="2"
                                  d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                        </svg>

                        View
                    </a>


                    <a href="<?php echo e(route('admin.exam-schedules.edit', $schedule)); ?>"
                       class="inline-flex items-center gap-1.5
                              px-3 py-2 rounded-lg
                              bg-amber-50 text-amber-600
                              hover:bg-amber-100
                              text-xs font-semibold transition">

                        <svg class="w-4 h-4"
                             fill="none"
                             stroke="currentColor"
                             viewBox="0 0 24 24">
                            <path stroke-linecap="round"
                                  stroke-linejoin="round"
                                  stroke-width="2"
                                  d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5"/>
                            <path stroke-linecap="round"
                                  stroke-linejoin="round"
                                  stroke-width="2"
                                  d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/>
                        </svg>

                        Edit
                    </a>


                    <form action="<?php echo e(route('admin.exam-schedules.destroy', $schedule)); ?>"
                          method="POST"
                          onsubmit="return confirm('Are you sure you want to delete this exam schedule?');">

                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>

                        <button type="submit"
                                class="inline-flex items-center gap-1.5
                                       px-3 py-2 rounded-lg
                                       bg-red-50 text-red-600
                                       hover:bg-red-100
                                       text-xs font-semibold transition">

                            <svg class="w-4 h-4"
                                 fill="none"
                                 stroke="currentColor"
                                 viewBox="0 0 24 24">
                                <path stroke-linecap="round"
                                      stroke-linejoin="round"
                                      stroke-width="2"
                                      d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                            </svg>

                            Delete
                        </button>

                    </form>

                </div>

            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <div class="bg-white border border-slate-200
                        rounded-xl shadow-sm px-5 py-12 text-center">

                <div class="w-14 h-14 rounded-full bg-slate-100
                            flex items-center justify-center mx-auto mb-3">

                    <svg class="w-7 h-7 text-slate-400"
                         fill="none"
                         stroke="currentColor"
                         viewBox="0 0 24 24">
                        <path stroke-linecap="round"
                              stroke-linejoin="round"
                              stroke-width="2"
                              d="M8 7V3m8 4V3m-9 4h10m-9 4h10m-9 4h10m-9 4h10"/>
                    </svg>

                </div>

                <h3 class="text-sm font-semibold text-slate-700">
                    No exam schedules found
                </h3>

                <p class="text-xs text-slate-500 mt-1">
                    Create your first exam schedule.
                </p>

                <a href="<?php echo e(route('admin.exam-schedules.create')); ?>"
                   class="mt-4 inline-flex items-center gap-2
                          px-4 py-2 rounded-lg
                          bg-blue-600 hover:bg-blue-700
                          text-white text-sm font-medium">

                    Add Schedule

                </a>

            </div>

        <?php endif; ?>


        
        <?php if($schedules->hasPages()): ?>

            <div class="bg-white border border-slate-200
                        rounded-xl shadow-sm px-4 py-4">

                <?php echo e($schedules->links()); ?>


            </div>

        <?php endif; ?>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\school-management\resources\views/admin/exam-schedules/index.blade.php ENDPATH**/ ?>