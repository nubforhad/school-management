<?php

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\AdmissionController;
use App\Http\Controllers\BranchController;
use App\Http\Controllers\AcademicSessionController;
use App\Http\Controllers\SchoolClassController;
use App\Http\Controllers\SectionController;
use App\Http\Controllers\SubjectController;
use App\Http\Controllers\ClassSubjectController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\StudentController;
use App\Http\Controllers\StudentEnrollmentController;
use App\Http\Controllers\AttendanceController;
use App\Http\Controllers\FeeTypeController;
use App\Http\Controllers\StudentFeeController;
use App\Http\Controllers\FeePaymentController; 
use App\Http\Controllers\FeeReportController;
use App\Http\Controllers\ExamController;
use App\Http\Controllers\ExamScheduleController;
use App\Http\Controllers\ExamSubjectController;
use App\Http\Controllers\ExamMarkController;
use App\Http\Controllers\StudentResultController;
use App\Http\Controllers\ClassResultController;
use App\Http\Controllers\ResultSheetController;
use App\Http\Controllers\DepartmentController;
use App\Http\Controllers\DesignationController;
use App\Http\Controllers\TeacherStaffController;
use App\Http\Controllers\TeacherAssignmentController;
use App\Http\Controllers\SalaryStructureController;
use App\Http\Controllers\SalaryPaymentController;
use App\Http\Controllers\LeaveTypeController;
use App\Http\Controllers\LeaveAllocationController;
use App\Http\Controllers\LeaveApplicationController;
use App\Http\Controllers\TeacherStaffAttendanceController;
use App\Http\Controllers\GuardianController;
use App\Http\Controllers\ClassRoutineController;
use App\Http\Controllers\FeeCollectionController;
use App\Http\Controllers\AccountController;
use App\Http\Controllers\SettingController;

use App\Http\Controllers\IncomeCategoryController;

use App\Http\Controllers\ExpenseCategoryController;
use App\Http\Controllers\ExpenseController;
use App\Http\Controllers\FinanceController;
use App\Http\Controllers\UserController;

use App\Http\Controllers\RoleController;
use App\Http\Controllers\UserRoleController;

 

Route::middleware(['auth'])->prefix('admin')->name('admin.')->group(function () {
        // Dynamic Role Management
        Route::middleware('permission:roles.view')->group(function () {
            Route::get('/roles', [RoleController::class, 'index'])->name('roles.index');
        });

        Route::middleware('permission:roles.create')->group(function () {
            Route::get('/roles/create', [RoleController::class, 'create'])->name('roles.create');
            Route::post('/roles', [RoleController::class, 'store'])->name('roles.store');
        });

        Route::middleware('permission:roles.edit')->group(function () {
            Route::get('/roles/{role}/edit', [RoleController::class, 'edit'])->name('roles.edit');
            Route::put('/roles/{role}', [RoleController::class, 'update'])->name('roles.update');
        });

        Route::middleware('permission:roles.delete')->group(function () {
            Route::delete('/roles/{role}', [RoleController::class, 'destroy'])->name('roles.destroy');
        });
        // User Role Assignment
        Route::middleware('permission:users.view')->group(function () {
            Route::get('/user-roles', [UserRoleController::class, 'index'])->name('user-roles.index');
        });
        Route::middleware('permission:users.edit')->group(function () {
            Route::get('/user-roles/{user}/edit', [UserRoleController::class, 'edit'])->name('user-roles.edit');
            Route::put('/user-roles/{user}', [UserRoleController::class, 'update'])->name('user-roles.update');
        });
    });

Route::get('/', [UserController::class, 'index'])->name('index');

    // ==============================
    // Authentication
    // ==============================

    Route::middleware('guest')->group(function () {
        Route::get('/register', [AuthController::class, 'showRegister'])->name('register');
        Route::post('/register', [AuthController::class, 'register'])->name('register.store');
        Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
        Route::post('/login', [AuthController::class, 'login'])->name('login.store');
    });

    Route::get('notices', [UserController::class, 'notice'])->name('notice');
    Route::get('contacts', [UserController::class, 'contact'])->name('contact');
    Route::get('about', [UserController::class, 'about'])->name('about');
    Route::get('teachers', [UserController::class, 'teachers'])->name('teachers');
    Route::get('objectives', [UserController::class, 'objective'])->name('objectives');

    Route::post('/logout', function () {
        Auth::logout();
        request()->session()->invalidate();
        request()->session()->regenerateToken();
        return redirect()->route('login');
    })->middleware('auth')->name('logout');

    Route::get('/dashboard', [DashboardController::class, 'index'])->middleware('auth')->name('dashboard');
        Route::get('/addmission', [AdmissionController::class, 'admission'])->name('admission');
        // Route::get('/dashboard', [DashboardController::class,  'index' ])->name('dashboard');
        Route::get('/students/{student}/id-card',  [StudentController::class, 'idCard'])->name('admin.students.id-card');

    // admin 
    Route::middleware('auth')
        ->prefix('admin')
        ->name('admin.')
        ->group(function () {
            Route::resource('branches', BranchController::class);
            Route::resource('students', StudentController::class );
            Route::get('students/{student}/print',  [StudentController::class, 'print'])->name('students.print');
            Route::get('students/{student}/pdf',  [StudentController::class, 'pdf'])->name('students.pdf');

        Route::prefix('academic')->name('academic.')->group(function () {
            Route::resource('sessions', AcademicSessionController::class);
            Route::resource('classes', SchoolClassController::class );
            Route::resource('sections', SectionController::class);
            Route::resource('subjects', SubjectController::class);
            Route::resource(  'class-subjects', ClassSubjectController::class);

        });
    }); 

    //Student Enrollment 
    
Route::prefix('admin')->name('admin.')->group(function () { 
        // Enrollment History
        Route::get( 'students/{student}/enrollments', [StudentEnrollmentController::class, 'index'] )->name('students.enrollments.index');
        // Create / Promote
        Route::get( 'students/{student}/enrollments/create', [StudentEnrollmentController::class, 'create'])->name('students.enrollments.create');
        // Store
        Route::post( 'students/{student}/enrollments', [StudentEnrollmentController::class, 'store'])->name('students.enrollments.store');
        // View
        Route::get('students/{student}/enrollments/{enrollment}',  [StudentEnrollmentController::class, 'show'])->name('students.enrollments.show');
        // Edit
        Route::get('students/{student}/enrollments/{enrollment}/edit',  [StudentEnrollmentController::class, 'edit'])->name('students.enrollments.edit');
        // Update
        Route::put( 'students/{student}/enrollments/{enrollment}', [StudentEnrollmentController::class, 'update'])->name('students.enrollments.update');
        // Delete
        Route::delete( 'students/{student}/enrollments/{enrollment}', [StudentEnrollmentController::class, 'destroy'])->name('students.enrollments.destroy');
        //Dynamic Sections 
        Route::get(  'enrollments/sections',  [StudentEnrollmentController::class, 'sections'])->name('students.enrollments.sections');


        Route::get('/settings/general', [SettingController::class, 'general'])->name('settings.general');
        Route::put('/settings/general', [SettingController::class, 'updateGeneral'])->name('settings.general.update');

        // bulk enrollment      
        Route::get( 'student-enrollments/bulk/create', [StudentEnrollmentController::class, 'bulkCreate'])->name('student-enrollments.bulk.create');
        Route::get( 'student-enrollments/bulk/students', [StudentEnrollmentController::class, 'bulkStudents'])->name('student-enrollments.bulk.students');
        Route::post( 'student-enrollments/bulk', [StudentEnrollmentController::class, 'bulkStore'])->name('student-enrollments.bulk.store');
        Route::get(  'student-enrollments/sections', [StudentEnrollmentController::class, 'sections'])->name('student-enrollments.sections');

        // attendance route 
        Route::prefix('attendance')->name('attendance.')->group(function () { 
            Route::get('/', [AttendanceController::class, 'index'])->name('index');
            Route::post('/store', [ AttendanceController::class, 'store'])->name('store');
        });
        Route::get(  'attendances/report', [AttendanceController::class, 'report'])->name('attendances.report');
        Route::get( 'attendance/analytics', [AttendanceController::class, 'analytics'])->name('attendance.analytics');
        Route::get( 'attendance/student-history', [AttendanceController::class, 'studentHistory'])->name('attendance.student-history');
        Route::get('attendance/{attendance}/edit',  [AttendanceController::class, 'edit'])->name('attendance.edit');
        Route::put( 'attendance/{attendance}',  [AttendanceController::class, 'update'])->name('attendance.update');
        Route::get('attendance/monthly-report', [AttendanceController::class, 'monthlyReport'])->name('attendance.monthly-report');
        // fee type date 23 08 26 Forhad
        Route::resource('fee-types', FeeTypeController::class)->except(['show'])->names('fee-types');
        Route::patch('fee-types/{feeType}/toggle-status',  [FeeTypeController::class, 'toggleStatus'])->name('fee-types.toggle-status');
        // Student Fee Assignment
        Route::resource( 'student-fees',  StudentFeeController::class)->names('student-fees');
        // Fee Collection
        Route::prefix('fee-collection')->name('fee-collection.')->group(function () {
            Route::get( '/', [FeePaymentController::class, 'index'])->name('index');
            Route::get( '/{studentFeeAssignment}/create',  [FeePaymentController::class, 'create'])->name('create');
            Route::post( '/{studentFeeAssignment}',  [FeePaymentController::class, 'store'] )->name('store');
            // Payment receipt
            Route::get('/payment/{payment}/receipt', [FeeCollectionController::class, 'receipt'])->name('receipt');
        });

    // Fee Payment History
    Route::get( 'fee-payment-history', [FeePaymentController::class, 'history'])->name('fee-payment-history.index');
    Route::get('fee-payment-history/{feePayment}', [FeePaymentController::class, 'show'])->name('fee-payment-history.show');
    Route::get('fee-payment-history/{feePayment}/receipt',  [FeePaymentController::class, 'receipt'])->name('fee-payment-history.receipt');    
    Route::get('/fee-reports/collection',  [FeeReportController::class, 'collection'])->name('fee-reports.collection');
    Route::get('fee-collection/report', [FeePaymentController::class, 'report'])->name('fee-collection.report');
    Route::get('/fee-collection/due-report', [FeePaymentController::class, 'dueReport'])->name('fee-collection.due-report');

    Route::resource('exams', ExamController::class); 
    Route::resource('exam-schedules', ExamScheduleController::class);
    Route::resource( 'exam-subjects',  ExamSubjectController::class);
    Route::resource('exam-marks', ExamMarkController::class);
    Route::get('student-results', [StudentResultController::class, 'index'])->name('student-results.index');
    Route::get('result-sheets', [ResultSheetController::class, 'show'])->name('result-sheets.show');
    Route::get( 'class-results',  [ClassResultController::class, 'index'])->name('class-results.index');
    // class-routines
    Route::resource('class-routines', ClassRoutineController::class)->names('class-routines');

  //  Route::resource( 'exams.schedules', ExamScheduleController::class)->names('exams.schedules');
    Route::resource('guardians', GuardianController::class)->names('guardians');
    Route::resource('income-categories', IncomeCategoryController::class);
    Route::resource('accounts', AccountController::class);

    //  departments
    Route::resource('departments', DepartmentController::class)->except(['show']);
    Route::resource('designations', DesignationController::class)->names('designations');
    Route::resource('teacher-staff', TeacherStaffController::class)->names('teacher-staff');
    Route::resource('teacher-assignment', TeacherAssignmentController::class)->except(['show'])->names('teacher-assignment');
    Route::resource( 'salary-structures',  SalaryStructureController::class)->except(['show'])->names('salary-structures');
    Route::resource( 'salary-payments', SalaryPaymentController::class)->names('salary-payments');
    Route::get('/salary-payments/salary-structure/{teacherStaffId}',[SalaryPaymentController::class, 'salaryStructure'])->name('salary-payments.salary-structure');

    Route::resource('leave-types',  LeaveTypeController::class)->names('leave-types');
    Route::resource('leave-allocations',  LeaveAllocationController::class)->names('leave-allocations');
     
    Route::prefix('leave-applications')
        ->name('leave-applications.') ->group(function () {
            Route::get('/', [LeaveApplicationController::class, 'index' ])->name('index');
            Route::get('/create', [LeaveApplicationController::class, 'create' ])->name('create');
            Route::post('/', [ LeaveApplicationController::class, 'store' ])->name('store');
            Route::get('/{leaveApplication}', [  LeaveApplicationController::class, 'show' ])->name('show');
            Route::get('/{leaveApplication}/edit', [  LeaveApplicationController::class,  'edit'])->name('edit');
            Route::put('/{leaveApplication}', [ LeaveApplicationController::class, 'update'])->name('update');
            Route::delete('/{leaveApplication}', [ LeaveApplicationController::class,   'destroy'])->name('destroy');
            Route::post('/{leaveApplication}/approve', [ LeaveApplicationController::class,  'approve' ])->name('approve');
            Route::post('/{leaveApplication}/reject', [  LeaveApplicationController::class, 'reject'])->name('reject');
        });

        Route::prefix('teacher-staff-attendance') ->name('teacher-staff-attendance.')
            ->group(function () {
                Route::get(  '/',  [TeacherStaffAttendanceController::class, 'index'] )->name('index');
                Route::get(  '/create', [TeacherStaffAttendanceController::class, 'create'] )->name('create');
                Route::post(  '/',  [TeacherStaffAttendanceController::class, 'store'] )->name('store');
                Route::get( '/{teacherStaffAttendance}', [TeacherStaffAttendanceController::class, 'show'])->name('show');
                Route::get( '/{teacherStaffAttendance}/edit', [TeacherStaffAttendanceController::class, 'edit'])->name('edit');
                Route::put( '/{teacherStaffAttendance}',  [TeacherStaffAttendanceController::class, 'update'] )->name('update');
                Route::delete(  '/{teacherStaffAttendance}', [TeacherStaffAttendanceController::class, 'destroy'] )->name('destroy');
                // Report — অবশ্যই /{attendance} এর আগে
                Route::get('/report', [ TeacherStaffAttendanceController::class, 'report' ])->name('report');
        });
        // expanse
        Route::resource('expense-categories', ExpenseCategoryController::class)->names('expense-categories');
        Route::resource('expenses', ExpenseController::class)->names('expenses');
        Route::get('finance', [FinanceController::class, 'index'])->name('finance.index'); 



        

        Route::get('/users', [UserController::class, 'adminUsers'])->name('users.index');
        Route::get('/users/create', [UserController::class, 'createUser'])->name('users.create');
        Route::post('/users', [UserController::class, 'storeUser'])->name('users.store');
        Route::get('/users/{user}/edit', [UserController::class, 'editUser'])->name('users.edit');
        Route::put('/users/{user}', [UserController::class, 'updateUser'])->name('users.update');
        Route::delete('/users/{user}', [UserController::class, 'deleteUser'])->name('users.destroy');


});


    // Route::prefix('exams')->name('admin.exams.')->group(function () {
    //     Route::get( 'schedules',  [ExamScheduleController::class, 'index'])->name('schedules.index');
    //     Route::get('schedules/create',  [ExamScheduleController::class, 'create'])->name('schedules.create');
    //     Route::post( 'schedules',  [ExamScheduleController::class, 'store'])->name('schedules.store');
    //     Route::get('schedules/{schedule}/edit',   [ExamScheduleController::class, 'edit'])->name('schedules.edit');
    //     Route::put(  'schedules/{schedule}',   [ExamScheduleController::class, 'update'])->name('schedules.update');
    //     Route::delete('schedules/{schedule}',  [ExamScheduleController::class, 'destroy'])->name('schedules.destroy');
    // });

    


