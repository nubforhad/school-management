

<?php $__env->startSection('content'); ?>

<div class="max-w-screen-2xl mx-auto px-3 sm:px-4 lg:px-6 py-4 sm:py-6">

     <!-- Header  -->

    <div class="mb-4 sm:mb-6">

        <div class="flex flex-col sm:flex-row
                    sm:items-center sm:justify-between gap-3">

            <div>

                <h1 class="text-xl sm:text-2xl font-bold text-slate-800">
                    Fee Types
                </h1>

                <p class="text-xs sm:text-sm text-slate-500 mt-1">
                    Manage fee types for your branch
                </p>

            </div>

            <a href="<?php echo e(route('admin.fee-types.create')); ?>"
               class="w-full sm:w-auto
                      inline-flex items-center justify-center gap-2
                      px-4 py-2.5 rounded-lg
                      bg-blue-600 text-white
                      text-sm font-medium
                      hover:bg-blue-700 transition">

                <i class="bi bi-plus-lg"></i>

                Add Fee Type

            </a>

        </div>

    </div>


    

    <?php if(session('success')): ?>

        <div class="mb-4 sm:mb-6
                    flex items-center gap-3
                    rounded-lg
                    border border-green-200
                    bg-green-50
                    px-4 py-3
                    text-sm text-green-700">

            <i class="bi bi-check-circle-fill"></i>

            <span>
                <?php echo e(session('success')); ?>

            </span>

        </div>

    <?php endif; ?>


    

    <?php if($errors->any()): ?>

        <div class="mb-4 sm:mb-6
                    rounded-lg
                    border border-red-200
                    bg-red-50
                    px-4 py-3
                    text-sm text-red-700">

            <div class="font-semibold mb-1">
                Please fix the following errors:
            </div>

            <ul class="list-disc pl-5 space-y-1">

                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <li><?php echo e($error); ?></li>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </ul>

        </div>

    <?php endif; ?>


    

    <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        
        <div class="p-3 sm:p-5 border-b border-slate-200">

            <div class="flex flex-col sm:flex-row
                        sm:items-center sm:justify-between gap-2">

                <div>

                    <h2 class="text-base sm:text-lg
                               font-semibold text-slate-800">

                        Fee Type List

                    </h2>

                    <p class="text-xs sm:text-sm text-slate-500 mt-1">

                        Available fee types in your branch

                    </p>

                </div>


                <div class="text-xs sm:text-sm text-slate-500">

                    Total:
                    <span class="font-semibold text-slate-700">
                        <?php echo e($feeTypes->count()); ?>

                    </span>

                </div>

            </div>

        </div>


        

        <div class="overflow-x-auto">

            <table class="w-full text-xs sm:text-sm min-w-[800px]">

                <thead class="bg-slate-50
                              border-b border-slate-200">

                    <tr>

                        <th class="px-3 sm:px-4 py-3 text-left
                                   font-semibold text-slate-600">
                            #
                        </th>

                        <th class="px-3 sm:px-4 py-3 text-left
                                   font-semibold text-slate-600">
                            Fee Type
                        </th>

                        <th class="px-3 sm:px-4 py-3 text-left
                                   font-semibold text-slate-600">
                            Code
                        </th>

                        <th class="px-3 sm:px-4 py-3 text-left
                                   font-semibold text-slate-600">
                            Branch
                        </th>

                        <th class="px-3 sm:px-4 py-3 text-left
                                   font-semibold text-slate-600">
                            Description
                        </th>

                        <th class="px-3 sm:px-4 py-3 text-left
                                   font-semibold text-slate-600">
                            Status
                        </th>

                        <th class="px-3 sm:px-4 py-3 text-right
                                   font-semibold text-slate-600">
                            Action
                        </th>

                    </tr>

                </thead>


                <tbody class="divide-y divide-slate-100">

                    <?php $__empty_1 = true; $__currentLoopData = $feeTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feeType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                        <tr class="hover:bg-slate-50 transition">


                            

                            <td class="px-3 sm:px-4 py-3
                                       text-slate-500">

                                <?php echo e($loop->iteration); ?>


                            </td>


                            

                            <td class="px-3 sm:px-4 py-3">

                                <div class="flex items-center gap-3">

                                    <div class="w-9 h-9 rounded-lg
                                                bg-blue-50
                                                flex items-center
                                                justify-center
                                                flex-shrink-0">

                                        <i class="bi bi-receipt
                                                  text-blue-600"></i>

                                    </div>

                                    <div>

                                        <div class="font-semibold
                                                    text-slate-800">

                                            <?php echo e($feeType->name); ?>


                                        </div>

                                        <div class="text-xs text-slate-400">

                                            Fee Type

                                        </div>

                                    </div>

                                </div>

                            </td>


                            

                            <td class="px-3 sm:px-4 py-3">

                                <?php if($feeType->code): ?>

                                    <span class="inline-flex
                                                 px-2.5 py-1
                                                 rounded-md
                                                 bg-slate-100
                                                 text-slate-700
                                                 border border-slate-200
                                                 text-xs font-medium">

                                        <?php echo e($feeType->code); ?>


                                    </span>

                                <?php else: ?>

                                    <span class="text-slate-400">
                                        —
                                    </span>

                                <?php endif; ?>

                            </td>


                            

                            <td class="px-3 sm:px-4 py-3">

                                <span class="text-slate-700">

                                    <?php echo e($feeType->branch->name ?? 'N/A'); ?>


                                </span>

                            </td>


                            

                            <td class="px-3 sm:px-4 py-3
                                       text-slate-500
                                       max-w-xs">

                                <?php if($feeType->description): ?>

                                    <?php echo e(\Illuminate\Support\Str::limit(
                                        $feeType->description,
                                        60
                                    )); ?>


                                <?php else: ?>

                                    <span class="text-slate-400">
                                        —
                                    </span>

                                <?php endif; ?>

                            </td>


                            

                            <td class="px-3 sm:px-4 py-3">

                                <?php if($feeType->status): ?>

                                    <span class="inline-flex
                                                 items-center gap-1.5
                                                 px-2.5 py-1
                                                 rounded-full
                                                 bg-green-50
                                                 text-green-700
                                                 border border-green-200">

                                        <span class="w-1.5 h-1.5
                                                     rounded-full
                                                     bg-green-500">
                                        </span>

                                        Active

                                    </span>

                                <?php else: ?>

                                    <span class="inline-flex
                                                 items-center gap-1.5
                                                 px-2.5 py-1
                                                 rounded-full
                                                 bg-red-50
                                                 text-red-700
                                                 border border-red-200">

                                        <span class="w-1.5 h-1.5
                                                     rounded-full
                                                     bg-red-500">
                                        </span>

                                        Inactive

                                    </span>

                                <?php endif; ?>

                            </td>


                            

                            <td class="px-3 sm:px-4 py-3">

                                <div class="flex items-center
                                            justify-end gap-2">


                                    

                                    <a href="<?php echo e(route(
                                        'admin.fee-types.edit',
                                        $feeType->id
                                    )); ?>"
                                    class="inline-flex
                                           items-center justify-center
                                           w-9 h-9
                                           rounded-lg
                                           bg-blue-50
                                           text-blue-600
                                           hover:bg-blue-100
                                           transition"
                                    title="Edit">

                                        <i class="bi bi-pencil-square"></i>

                                    </a>


                                    

                                    <form method="POST"
                                          action="<?php echo e(route(
                                              'admin.fee-types.toggle-status',
                                              $feeType->id
                                          )); ?>">

                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>

                                        <button type="submit"
                                                class="inline-flex
                                                       items-center
                                                       justify-center
                                                       w-9 h-9
                                                       rounded-lg
                                                       <?php echo e($feeType->status
                                                            ? 'bg-yellow-50 text-yellow-600 hover:bg-yellow-100'
                                                            : 'bg-green-50 text-green-600 hover:bg-green-100'); ?>

                                                       transition"
                                                title="<?php echo e($feeType->status ? 'Deactivate' : 'Activate'); ?>">

                                            <i class="bi
                                                <?php echo e($feeType->status
                                                    ? 'bi-toggle-on'
                                                    : 'bi-toggle-off'); ?>">
                                            </i>

                                        </button>

                                    </form>


                                    

                                    <form method="POST"
                                          action="<?php echo e(route(
                                              'admin.fee-types.destroy',
                                              $feeType->id
                                          )); ?>"
                                          onsubmit="return confirm(
                                              'Are you sure you want to delete this fee type?'
                                          )">

                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>

                                        <button type="submit"
                                                class="inline-flex
                                                       items-center
                                                       justify-center
                                                       w-9 h-9
                                                       rounded-lg
                                                       bg-red-50
                                                       text-red-600
                                                       hover:bg-red-100
                                                       transition"
                                                title="Delete">

                                            <i class="bi bi-trash"></i>

                                        </button>

                                    </form>

                                </div>

                            </td>

                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <tr>

                            <td colspan="7"
                                class="px-4 py-12 text-center">

                                <div class="flex flex-col
                                            items-center">

                                    <div class="w-16 h-16
                                                rounded-full
                                                bg-blue-50
                                                flex items-center
                                                justify-center mb-4">

                                        <i class="bi bi-receipt
                                                  text-3xl
                                                  text-blue-600"></i>

                                    </div>

                                    <h3 class="text-sm sm:text-base
                                               font-semibold
                                               text-slate-700">

                                        No Fee Types Found

                                    </h3>

                                    <p class="text-xs sm:text-sm
                                              text-slate-500 mt-1">

                                        Create your first fee type
                                        for this branch.

                                    </p>

                                    <a href="<?php echo e(route(
                                        'admin.fee-types.create'
                                    )); ?>"
                                    class="mt-4
                                           inline-flex
                                           items-center gap-2
                                           px-4 py-2.5
                                           rounded-lg
                                           bg-blue-600
                                           text-white
                                           text-sm
                                           font-medium
                                           hover:bg-blue-700
                                           transition">

                                        <i class="bi bi-plus-lg"></i>

                                        Add Fee Type

                                    </a>

                                </div>

                            </td>

                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\school-management\resources\views/admin/fee-types/index.blade.php ENDPATH**/ ?>