


<?php $__env->startSection('content'); ?>
<div class="space-y-5 p-4 md:p-6">
    <div class="flex flex-wrap items-center justify-between gap-3">
        <div>
            <h1 class="text-2xl font-bold text-slate-800">Role Management</h1>
            <p class="mt-1 text-sm text-slate-500">
                Manage system roles and permissions.
            </p>
        </div>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.create')): ?>
            <a href="<?php echo e(route('admin.roles.create')); ?>"
               class="rounded-lg bg-blue-600 px-4 py-2 text-white hover:bg-blue-700">
                + Create Role
            </a>
        <?php endif; ?>
    </div>
    <?php if(session('success')): ?>
        <div class="rounded-lg border border-green-200 bg-green-50 p-3 text-green-700">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="rounded-lg border border-red-200 bg-red-50 p-3 text-red-700">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>
    <div class="overflow-x-auto rounded-xl border border-slate-200 bg-white">
        <table class="w-full text-left text-sm">
            <thead class="bg-slate-50 text-slate-600">
                <tr>
                    <th class="p-3">#</th>
                    <th class="p-3">Role Name</th>
                    <th class="p-3">Permissions</th>
                    <th class="p-3">Users</th>
                    <th class="p-3 text-right">Actions</th>
                </tr>
            </thead>

            <tbody class="divide-y divide-slate-100">
                <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="p-3">
                            <?php echo e($roles->firstItem() + $loop->index); ?>

                        </td>
                        <td class="p-3 font-medium text-slate-800">
                            <?php echo e($role->name); ?>

                        </td>

                        <td class="p-3">
                            <span class="rounded-full bg-blue-50 px-3 py-1 text-blue-700">
                                <?php echo e($role->permissions_count); ?>

                            </span>
                        </td>
                        <td class="p-3">
                            <?php echo e($role->users_count); ?>

                        </td>

                        <td class="p-3">
                            <div class="flex justify-end gap-2">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.edit')): ?>
                                    <a href="<?php echo e(route('admin.roles.edit', $role)); ?>"
                                       class="rounded-md border border-slate-200 px-3 py-1.5 hover:bg-slate-50">
                                        Edit
                                    </a>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.delete')): ?>
                                    <?php if($role->name !== 'Super Admin'): ?>
                                        <form action="<?php echo e(route('admin.roles.destroy', $role)); ?>"
                                              method="POST"
                                              onsubmit="return confirm('Delete this role?')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>

                                            <button type="submit"
                                                    class="rounded-md bg-red-50 px-3 py-1.5 text-red-700 hover:bg-red-100">
                                                Delete
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="p-8 text-center text-slate-500">
                            No roles found.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php echo e($roles->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\school-management\resources\views/admin/roles/index.blade.php ENDPATH**/ ?>