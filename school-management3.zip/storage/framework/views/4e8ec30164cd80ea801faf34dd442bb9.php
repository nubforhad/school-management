<?php
    $menu = \App\Support\SidebarMenu::build(auth()->user());
?>

<aside id="sidebar" class="fixed inset-y-0 left-0 z-50 w-64 -translate-x-full lg:translate-x-0 bg-slate-900 text-white border-r border-slate-800 transition-transform duration-300 ease-in-out flex flex-col">

    
    <div class="flex h-16 shrink-0 items-center justify-between px-4 border-b border-slate-800">
        <a href="<?php echo e(route('dashboard')); ?>" class="flex items-center gap-3 min-w-0">
            <div class="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 shadow-lg shadow-blue-900/40 ring-1 ring-white/10">
                <img src="<?php echo e(asset('asset/image/imagelogo.png')); ?>" alt="logo">
            </div>
            <div class="min-w-0">
                <h1 class="font-semibold text-sm text-white truncate">Madrasah ERP</h1>
                <p class="text-[11px] text-slate-500 truncate">Administration</p>
            </div>
        </a>
        <button type="button" onclick="closeSidebar()" class="lg:hidden flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 hover:bg-slate-800 hover:text-white transition">
            <i class="bi bi-x-lg text-sm"></i>
        </button>
    </div>

    
    <div class="flex-1 overflow-y-auto px-3 py-4 sidebar-scroll">
        <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p class="px-3 mb-2 <?php echo e($loop->first ? '' : 'mt-7'); ?> text-[10px] font-semibold uppercase tracking-[0.12em] text-slate-500"><?php echo e($section['title']); ?></p>

            <nav class="space-y-1">
                <?php $__currentLoopData = $section['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php if(isset($item['children'])): ?>
                        
                        <div class="nav-group">
                            <button type="button" onclick="toggleNavGroup(this)"
                                class="nav-group-title w-full flex items-center justify-between text-left <?php echo e($item['is_active'] ? 'active' : ''); ?>">
                                <div class="flex items-center gap-3">
                                    <span class="nav-icon <?php echo e($item['is_active'] ? 'bg-white/15 text-white' : 'bg-slate-800 text-slate-300'); ?>">
                                        <i class="bi <?php echo e($item['icon']); ?>"></i>
                                    </span>
                                    <span><?php echo e($item['title']); ?></span>
                                </div>
                                <i class="bi bi-chevron-down nav-group-arrow text-slate-500 transition-transform duration-300"></i>
                            </button>

                            <div class="nav-submenu <?php echo e($item['is_active'] ? '' : 'hidden'); ?>">
                                <?php $__currentLoopData = $item['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e(route($child['route'])); ?>" class="nav-link group <?php echo e($child['is_active'] ? 'nav-link-active' : ''); ?>">
                                        <span class="nav-icon <?php echo e($child['is_active'] ? 'bg-white/15 text-white' : 'bg-slate-800 text-slate-400 group-hover:bg-blue-600 group-hover:text-white'); ?>">
                                            <i class="bi <?php echo e($child['icon']); ?>"></i>
                                        </span>
                                        <span><?php echo e($child['title']); ?></span>
                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php else: ?>
                        
                        <a href="<?php echo e(route($item['route'])); ?>" class="nav-link group <?php echo e($item['is_active'] ? 'nav-link-active' : ''); ?>">
                            <span class="nav-icon <?php echo e($item['is_active'] ? 'bg-white/15 text-white' : 'bg-slate-800 ' . ($item['color'] ?? 'text-slate-400')); ?>">
                                <i class="bi <?php echo e($item['icon']); ?>"></i>
                            </span>
                            <span><?php echo e($item['title']); ?></span>
                        </a>
                    <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </nav>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    
    <div class="shrink-0 border-t border-slate-800 p-3">
        <div class="flex items-center gap-3 rounded-xl bg-slate-800/60 px-3 py-2.5 ring-1 ring-white/5">
            <div class="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 shadow-md shadow-blue-900/30">
                <i class="bi bi-person-fill text-sm"></i>
            </div>
            <div class="min-w-0">
                <p class="text-xs font-medium text-white truncate"><?php echo e(auth()->user()->name); ?></p>
                <p class="text-[10px] text-slate-500 truncate"><?php echo e(auth()->user()->getRoleNames()->first() ?? 'Madrasah ERP'); ?></p>
            </div>
        </div>
    </div>
</aside>

<div id="sidebarOverlay" onclick="closeSidebar()" class="fixed inset-0 z-40 hidden bg-black/50 backdrop-blur-sm lg:hidden"></div>

<style>
    .sidebar-scroll { scrollbar-width: thin; scrollbar-color: #334155 transparent; }
    .sidebar-scroll::-webkit-scrollbar { width: 5px; }
    .sidebar-scroll::-webkit-scrollbar-track { background: transparent; }
    .sidebar-scroll::-webkit-scrollbar-thumb { background: #334155; border-radius: 10px; }

    .nav-link { display: flex; align-items: center; gap: .75rem; border-radius: .65rem; padding: .5rem .625rem; font-size: .875rem; font-weight: 500; color: #cbd5e1; transition: background-color .15s ease, color .15s ease, transform .1s ease; }
    .nav-link:hover { background-color: #1e293b; color: #fff; }
    .nav-link:active { transform: scale(.98); }
    .nav-link-active { background: linear-gradient(135deg, #2563eb, #4f46e5); color: #fff; box-shadow: 0 4px 14px -4px rgba(37, 99, 235, .5); }
    .nav-link-active:hover { background: linear-gradient(135deg, #2563eb, #4f46e5); }

    .nav-icon { display: flex; align-items: center; justify-content: center; flex-shrink: 0; width: 2rem; height: 2rem; border-radius: .55rem; font-size: .95rem; transition: background-color .15s ease, color .15s ease; }

    /* Groups (ek bar e define kora; age 3 bar duplicate chilo) */
    .nav-group-title { border: 0; background: transparent; cursor: pointer; padding: 10px 12px; color: #cbd5e1; transition: all .25s ease; border-radius: 10px; }
    .nav-group-title:hover { background: rgba(30, 41, 59, .7); color: #fff; }
    .nav-group-arrow { font-size: 12px; }
    .nav-group-title.active .nav-group-arrow { transform: rotate(180deg); }
    .nav-group-title.active { background: rgba(30, 41, 59, .8); color: #fff; }

    .nav-submenu { margin-left: 12px; padding-left: 14px; border-left: 1px solid rgba(148, 163, 184, .15); overflow: hidden; animation: submenuOpen .25s ease; }
    .nav-submenu .nav-link { position: relative; margin-top: 3px; padding-left: 10px; }
    .nav-submenu .nav-link::before { content: ""; position: absolute; left: -15px; top: 50%; width: 8px; height: 1px; background: rgba(148, 163, 184, .25); transition: all .2s ease; }
    .nav-submenu .nav-link:hover::before { width: 14px; background: #3b82f6; }

    @keyframes submenuOpen { from { opacity: 0; transform: translateY(-5px); } to { opacity: 1; transform: translateY(0); } }
</style>

<script>
    function openSidebar() {
        document.getElementById("sidebar")?.classList.remove("-translate-x-full");
        document.getElementById("sidebarOverlay")?.classList.remove("hidden");
        document.body.classList.add("overflow-hidden");
    }

    function closeSidebar() {
        document.getElementById("sidebar")?.classList.add("-translate-x-full");
        document.getElementById("sidebarOverlay")?.classList.add("hidden");
        document.body.classList.remove("overflow-hidden");
    }

    function toggleNavGroup(btn) {
        btn.classList.toggle("active");
        btn.parentElement.querySelector(".nav-submenu")?.classList.toggle("hidden");
    }

    document.addEventListener("DOMContentLoaded", function () {
        document.querySelectorAll("#sidebar a").forEach(function (link) {
            link.addEventListener("click", function () {
                if (window.innerWidth < 1024) closeSidebar();
            });
        });
    });
</script><?php /**PATH C:\xampp\htdocs\school-management\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>