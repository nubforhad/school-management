

<?php $__env->startSection('title', 'Salary Structures'); ?>

<?php $__env->startSection('page-title', 'Salary Structures'); ?>

<?php $__env->startSection('content'); ?>

<div class="max-w-screen-xl mx-auto px-3 sm:px-4 lg:px-6 py-4 sm:py-6">
 

<div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">

    <div>
        <h1 class="text-xl sm:text-2xl font-bold text-slate-800">
            Salary Structures
        </h1>

        <p class="mt-1 text-xs sm:text-sm text-slate-500">
            Manage teacher and staff salary structures
        </p>
    </div>

    <a href="<?php echo e(route('admin.salary-structures.create')); ?>"
       class="inline-flex items-center justify-center gap-2
              rounded-lg bg-blue-600 px-4 py-2.5
              text-sm font-semibold text-white
              hover:bg-blue-700 transition">

        <i class="bi bi-plus-lg"></i>

        Add Salary Structure

    </a>

</div>



<?php if(session('success')): ?>

    <div class="mb-5 flex items-center gap-3
                rounded-lg border border-green-200
                bg-green-50 px-4 py-3">

        <div class="flex h-8 w-8 shrink-0 items-center justify-center
                    rounded-full bg-green-100 text-green-600">

            <i class="bi bi-check-circle"></i>

        </div>

        <p class="text-sm font-medium text-green-700">
            <?php echo e(session('success')); ?>

        </p>

    </div>

<?php endif; ?>



<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">

    
    <div class="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">

        <div class="flex items-center justify-between">

            <div>
                <p class="text-xs font-medium text-slate-500">
                    Total Structures
                </p>

                <p class="mt-1 text-2xl font-bold text-slate-800">
                    <?php echo e($salaryStructures->total()); ?>

                </p>
            </div>

            <div class="flex h-10 w-10 items-center justify-center
                        rounded-lg bg-blue-50 text-blue-600">

                <i class="bi bi-wallet2 text-lg"></i>

            </div>

        </div>

    </div>


    
    <div class="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">

        <div class="flex items-center justify-between">

            <div>
                <p class="text-xs font-medium text-slate-500">
                    Active
                </p>

                <p class="mt-1 text-2xl font-bold text-green-600">
                    <?php echo e($salaryStructures->where('status', true)->count()); ?>

                </p>
            </div>

            <div class="flex h-10 w-10 items-center justify-center
                        rounded-lg bg-green-50 text-green-600">

                <i class="bi bi-check-circle text-lg"></i>

            </div>

        </div>

    </div>


    
    <div class="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">

        <div class="flex items-center justify-between">

            <div>
                <p class="text-xs font-medium text-slate-500">
                    Inactive
                </p>

                <p class="mt-1 text-2xl font-bold text-red-600">
                    <?php echo e($salaryStructures->where('status', false)->count()); ?>

                </p>
            </div>

            <div class="flex h-10 w-10 items-center justify-center
                        rounded-lg bg-red-50 text-red-600">

                <i class="bi bi-x-circle text-lg"></i>

            </div>

        </div>

    </div>


    
    <div class="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">

        <div class="flex items-center justify-between">

            <div>
                <p class="text-xs font-medium text-slate-500">
                    Showing
                </p>

                <p class="mt-1 text-2xl font-bold text-slate-800">
                    <?php echo e($salaryStructures->count()); ?>

                </p>
            </div>

            <div class="flex h-10 w-10 items-center justify-center
                        rounded-lg bg-slate-100 text-slate-600">

                <i class="bi bi-list-ul text-lg"></i>

            </div>

        </div>

    </div>

</div>



<div class="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">

    
    <div class="px-4 sm:px-6 py-4 border-b border-slate-200 bg-slate-50">

        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">

            <div>

                <h2 class="font-semibold text-slate-800">
                    Salary Structure List
                </h2>

                <p class="text-xs text-slate-500 mt-0.5">
                    Teacher and staff salary details
                </p>

            </div>

        </div>

    </div>


    
    <div class="overflow-x-auto">

        <table class="w-full min-w-[1100px] text-sm">

            <thead class="bg-slate-50 border-b border-slate-200">

                <tr>

                    <th class="px-4 py-3 text-left font-semibold text-slate-600">
                        #
                    </th>

                    <th class="px-4 py-3 text-left font-semibold text-slate-600">
                        Teacher / Staff
                    </th>

                    <th class="px-4 py-3 text-left font-semibold text-slate-600">
                        Department
                    </th>

                    <th class="px-4 py-3 text-left font-semibold text-slate-600">
                        Designation
                    </th>

                    <th class="px-4 py-3 text-right font-semibold text-slate-600">
                        Basic
                    </th>

                    <th class="px-4 py-3 text-right font-semibold text-slate-600">
                        Gross
                    </th>

                    <th class="px-4 py-3 text-right font-semibold text-slate-600">
                        Deduction
                    </th>

                    <th class="px-4 py-3 text-right font-semibold text-slate-600">
                        Net Salary
                    </th>

                    <th class="px-4 py-3 text-center font-semibold text-slate-600">
                        Status
                    </th>

                    <th class="px-4 py-3 text-center font-semibold text-slate-600">
                        Action
                    </th>

                </tr>

            </thead>


            <tbody class="divide-y divide-slate-100">

                <?php $__empty_1 = true; $__currentLoopData = $salaryStructures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <tr class="hover:bg-slate-50 transition">

                        
                        <td class="px-4 py-3 text-slate-500">

                            <?php echo e($salaryStructures->firstItem() + $loop->index); ?>


                        </td>


                        
                        <td class="px-4 py-3">

                            <div class="flex items-center gap-3">

                                <?php if($salary->teacherStaff?->photo): ?>

                                    <img
                                        src="<?php echo e(asset('storage/' . $salary->teacherStaff->photo)); ?>"
                                        alt="<?php echo e($salary->teacherStaff->name); ?>"
                                        class="h-9 w-9 rounded-full object-cover border border-slate-200"
                                    >

                                <?php else: ?>

                                    <div class="flex h-9 w-9 shrink-0
                                                items-center justify-center
                                                rounded-full bg-blue-50
                                                text-blue-600">

                                        <i class="bi bi-person"></i>

                                    </div>

                                <?php endif; ?>


                                <div>

                                    <p class="font-medium text-slate-800">

                                        <?php echo e($salary->teacherStaff?->name ?? 'N/A'); ?>


                                    </p>

                                    <?php if($salary->teacherStaff?->employee_id): ?>

                                        <p class="text-xs text-slate-400">

                                            <?php echo e($salary->teacherStaff->employee_id); ?>


                                        </p>

                                    <?php endif; ?>

                                </div>

                            </div>

                        </td>


                        
                        <td class="px-4 py-3 text-slate-600">

                            <?php echo e($salary->teacherStaff?->department?->name ?? 'N/A'); ?>


                        </td>


                        
                        <td class="px-4 py-3 text-slate-600">

                            <?php echo e($salary->teacherStaff?->designation?->name ?? 'N/A'); ?>


                        </td>


                        
                        <td class="px-4 py-3 text-right font-medium text-slate-700">

                            ৳<?php echo e(number_format((float) $salary->basic_salary, 2)); ?>


                        </td>


                        
                        <td class="px-4 py-3 text-right font-medium text-blue-600">

                            ৳<?php echo e(number_format((float) $salary->gross_salary, 2)); ?>


                        </td>


                        
                        <td class="px-4 py-3 text-right font-medium text-red-600">

                            ৳<?php echo e(number_format((float) $salary->total_deduction, 2)); ?>


                        </td>


                        
                        <td class="px-4 py-3 text-right font-semibold text-green-600">

                            ৳<?php echo e(number_format((float) $salary->net_salary, 2)); ?>


                        </td>


                        
                        <td class="px-4 py-3 text-center">

                            <?php if($salary->status): ?>

                                <span class="inline-flex items-center gap-1
                                             rounded-full bg-green-50
                                             px-2.5 py-1 text-xs
                                             font-medium text-green-700">

                                    <span class="h-1.5 w-1.5 rounded-full bg-green-500"></span>

                                    Active

                                </span>

                            <?php else: ?>

                                <span class="inline-flex items-center gap-1
                                             rounded-full bg-red-50
                                             px-2.5 py-1 text-xs
                                             font-medium text-red-700">

                                    <span class="h-1.5 w-1.5 rounded-full bg-red-500"></span>

                                    Inactive

                                </span>

                            <?php endif; ?>

                        </td>


                        
                        <td class="px-4 py-3">

                            <div class="flex items-center justify-center gap-2">

                                
                                <a href="<?php echo e(route('admin.salary-structures.edit', $salary->id)); ?>"
                                   title="Edit"
                                   class="inline-flex h-9 w-9 items-center justify-center
                                          rounded-lg bg-blue-50 text-blue-600
                                          hover:bg-blue-100 transition">

                                    <i class="bi bi-pencil-square"></i>

                                </a>


                                
                                <form action="<?php echo e(route('admin.salary-structures.destroy', $salary->id)); ?>"
                                      method="POST"
                                      onsubmit="return confirm('Are you sure you want to delete this salary structure?');">

                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>

                                    <button type="submit"
                                            title="Delete"
                                            class="inline-flex h-9 w-9 items-center justify-center
                                                   rounded-lg bg-red-50 text-red-600
                                                   hover:bg-red-100 transition">

                                        <i class="bi bi-trash3"></i>

                                    </button>

                                </form>

                            </div>

                        </td>

                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <tr>

                        <td colspan="10" class="px-6 py-12 text-center">

                            <div class="flex flex-col items-center justify-center">

                                <div class="flex h-14 w-14 items-center justify-center
                                            rounded-full bg-slate-100 text-slate-400">

                                    <i class="bi bi-wallet2 text-2xl"></i>

                                </div>

                                <h3 class="mt-3 text-sm font-semibold text-slate-700">
                                    No Salary Structures Found
                                </h3>

                                <p class="mt-1 text-xs text-slate-500">
                                    Add a salary structure for a teacher or staff member.
                                </p>

                                <a href="<?php echo e(route('admin.salary-structures.create')); ?>"
                                   class="mt-4 inline-flex items-center gap-2
                                          rounded-lg bg-blue-600 px-4 py-2
                                          text-xs font-semibold text-white
                                          hover:bg-blue-700 transition">

                                    <i class="bi bi-plus-lg"></i>

                                    Add Salary Structure

                                </a>

                            </div>

                        </td>

                    </tr>

                <?php endif; ?>

            </tbody>

        </table>

    </div>


    
    <?php if($salaryStructures->hasPages()): ?>

        <div class="px-4 sm:px-6 py-4 border-t border-slate-200 bg-white">

            <?php echo e($salaryStructures->links()); ?>


        </div>

    <?php endif; ?>

</div> 

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\school-management\resources\views/admin/salary-structures/index.blade.php ENDPATH**/ ?>